'use strict';
/**
 * The app's side of the helper's control socket (native/checks/README.md). Each command gets one JSON line, in order.
 *
 *   send(line, ms) -> Promise of the answer, { ok: false, error, unreachable } when the helper cannot be reached
 *   on 'up': the helper is there (again). 'down': it went.
 *   lastError: why the last try failed, for the report: EACCES says something other than ENOENT
 */
const EventEmitter = require('events');
const net = require('net');

const RECONNECT_MS = 2000;
const UNREACHABLE = 'The helper is not running. If you just installed it, restart the head unit: it starts then. If not, install YouTube Checks helper in the Store';

class HelperClient extends EventEmitter {
    constructor(path) {
        super();
        this.path = path;
        this.sock = null;
        this.up = false;
        this.closed = false;
        this.buf = '';
        this.waiting = [];
        this.retry = null;
        this.lastError = null;
    }
    connect() {
        if (this.closed || this.sock) return;
        const s = net.connect(this.path);
        this.sock = s;
        s.setEncoding('utf8');
        s.on('connect', () => {
            this.up = true;
            this.lastError = null;
            this.emit('up');
        });
        s.on('data', (d) => this._data(d));
        s.on('error', (e) => { this.lastError = e.code || e.message; });
        s.on('close', () => this._down());
    }
    _down() {
        const was = this.up;
        this.sock = null;
        this.up = false;
        this.buf = '';
        const waiting = this.waiting;
        this.waiting = [];
        waiting.forEach((w) => this._answer(w, { ok: false, error: UNREACHABLE, unreachable: true }));
        if (was) this.emit('down');
        if (!this.closed && !this.retry) {
            this.retry = setTimeout(() => {
                this.retry = null;
                this.connect();
            }, RECONNECT_MS);
        }
    }
    _answer(w, a) {
        clearTimeout(w.timer);
        w.resolve(a);
    }
    _data(d) {
        this.buf += d;
        let i;
        while ((i = this.buf.indexOf('\n')) >= 0) {
            const line = this.buf.slice(0, i);
            this.buf = this.buf.slice(i + 1);
            const w = this.waiting.shift();
            if (!w) continue;
            let a;
            try {
                a = JSON.parse(line);
            } catch (e) {
                a = { ok: false, error: 'The helper gave a bad answer' };
            }
            this._answer(w, a);
        }
    }
    send(line, ms) {
        return new Promise((resolve) => {
            if (!this.up) {
                resolve({ ok: false, error: UNREACHABLE, unreachable: true });
                return;
            }
            const w = { resolve, timer: null };
            /* a helper that stays silent: this connection is no use any more */
            w.timer = setTimeout(() => {
                if (this.sock) this.sock.destroy();
            }, ms || 10000);
            this.waiting.push(w);
            this.sock.write(`${line}\n`);
        });
    }
    close() {
        this.closed = true;
        clearTimeout(this.retry);
        if (this.sock) this.sock.destroy();
    }
}

module.exports = { HelperClient, UNREACHABLE };
