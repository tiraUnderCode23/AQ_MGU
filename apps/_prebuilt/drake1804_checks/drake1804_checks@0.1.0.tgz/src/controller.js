'use strict';
/**
 * What a press means, what is asked of the helper, and the model the screens draw. No sdk, no renderer.
 */
const fs = require('fs');

const REPORT_MS = 240000;
const VIDEO_MS = 120000;
const PLAYER_MS = 180000;
const PROBE_MS = 240000;
const SHORT_MS = 30000;
const LEVELS = ['-30', '-20'];
const BETWEEN_TONES_MS = 1000;
const TICK_MS = 1000;

class Controller {
    /* host: { log, helper, screen, version, socket } */
    constructor(host) {
        this.log = host.log;
        this.helper = host.helper;
        this.screen = host.screen;
        this.version = host.version;
        this.socket = host.socket;
        this.helperVersion = null;
        this.busy = null;
        this.result = null;
        this.ticking = null;
        this.sound = { devices: [], saved: null, level: LEVELS[0], results: {}, last: null, status: '', message: '', page: 0, playing: false, stop: false };
        this.snapshot = {};
        this.helper.on('up', () => this._hello());
        this.helper.on('down', () => {
            this.helperVersion = null;
            this.screen.render();
        });
        this.screen.on('page-closed', (page) => {
            if (page === 'sound') this.sound.stop = true;
        });
    }

    start() { this.helper.connect(); }

    stop() {
        clearInterval(this.ticking);
        this.sound.stop = true;
    }

    _hello() {
        this.helper.send('ping', SHORT_MS).then((a) => {
            if (a.ok) this.helperVersion = a.version;
            this.log.info(`helper ${a.ok ? a.version : a.error}`);
            this.screen.render();
        });
    }

    model() {
        return {
            version: this.version,
            helper: { up: this.helper.up, version: this.helperVersion },
            busy: this.busy && { title: this.busy.title, hint: this.busy.hint, seconds: Math.round((Date.now() - this.busy.since) / 1000) },
            result: this.result,
            sound: this.sound,
            snapshot: this.snapshot
        };
    }

    act(a) {
        switch (a.do) {
        case 'report':
            return this._run('report', { title: 'Running all checks', hint: 'This takes up to a minute, and only reads.', ms: REPORT_MS, fallback: 'All checks' });
        case 'video':
            return this._run('video', { title: 'Video test', hint: 'Colour bars should fill this area for about 45 seconds, moving for the last 30. Results follow.', ms: VIDEO_MS, hold: true, fallback: 'Video test' });
        case 'player':
            return this._run('player', { title: 'Player test', hint: 'Searching YouTube, then playing a video out of sight for 30 seconds. Nothing shows while it plays.', ms: PLAYER_MS, fallback: 'Player test' });
        case 'sound':
            this.screen.push('sound');
            return this._devices();
        case 'snapshot':
            return this.screen.push('snapshot');
        case 'last':
            return this.screen.push('report');
        case 'page':
            return this.screen.turnPage(a.by);
        case 'part':
            return this.screen.nextPart();
        case 'tone':
            return this._tone(a.name);
        case 'toneAll':
            return this._toneAll();
        case 'level':
            this.sound.level = LEVELS[(LEVELS.indexOf(this.sound.level) + 1) % LEVELS.length];
            return this.screen.render();
        case 'keep':
            return this._keep();
        case 'moreDevices': {
            const count = this.sound.devices.filter((d) => d.cls !== 'leave').length;
            this.sound.page = (this.sound.page + 1) % Math.ceil(count / 5);
            return this.screen.render();
        }
        case 'probe':
            return this._probe(a.label);
        default:
            return undefined;
        }
    }

    /* A job on a report page of its own, which waits and then holds the answer. BACK leaves it running: Last results finds the answer. */
    _run(line, o) {
        if (this.busy) {
            if (this.screen.top() !== 'report') this.screen.push('report');
            return Promise.resolve();
        }
        this.log.info(`run: ${line}`);
        this.busy = { title: o.title, hint: o.hint, since: Date.now() };
        if (this.screen.top() !== 'report') this.screen.push('report');
        this.screen.hold(!!o.hold);
        this.screen.render();
        clearInterval(this.ticking);
        this.ticking = setInterval(() => this.screen.render(), TICK_MS);
        return this.helper.send(line, o.ms).then((a) => {
            clearInterval(this.ticking);
            this.busy = null;
            this.result = this._resultOf(a, o.fallback);
            this.log.info(`done: ${line}: ${a.ok ? 'ok' : a.error}`);
            this.screen.hold(false);
            this.screen.showResult();
            return a;
        });
    }

    _resultOf(a, title) {
        const sections = a.sections ? a.sections.slice() : [];
        if (!a.ok) sections.unshift({ title: `${title}: did not finish`, lines: [`FAIL  ${a.error || 'no answer'}`] });
        sections.push({ title: 'This app', lines: this._selfLines() });
        return { title: a.title || title, at: a.at || new Date().toISOString().slice(0, 19), sections };
    }

    /* What only this side knows: it is what tells a helper not running from an app that may not reach it. */
    _selfLines() {
        const lines = [`YouTube Checks ${this.version}, node ${process.version}`];
        lines.push(`uid ${process.getuid()}, gid ${process.getgid()}, groups ${process.getgroups().join(' ')}`);
        lines.push(`Helper ${this.helper.up ? `up, ${this.helperVersion}` : `down, last error ${this.helper.lastError || 'none'}`}`);
        try {
            const st = fs.statSync(this.socket);
            lines.push(`${this.socket}: mode ${(st.mode & 0o7777).toString(8)}, owner ${st.uid}:${st.gid}`);
        } catch (e) {
            lines.push(`${this.socket}: ${e.code}`);
        }
        const info = this.screen.rendererInfo;
        if (this.screen.available && info) {
            const box = info.appArea;
            lines.push(`Renderer: layer ${box.w}x${box.h} at ${box.x},${box.y}, modes ${info.modes.join(' ')}, video ${!!info.video}, controller ${!!info.controller}`);
        } else {
            lines.push(`Renderer: not in use: ${this.screen.rendererWhy || 'no reason known'}`);
        }
        return lines;
    }

    /* ---- sound ---- */

    _devices() {
        const s = this.sound;
        s.page = 0;
        s.stop = false;
        s.message = '';
        return this.helper.send('devices', SHORT_MS).then((a) => {
            if (!a.ok) s.message = a.error;
            else if (!a.helper) s.message = 'The sound helper comes with the YouTube player tool: install YouTube in the Store first.';
            else if (!a.devices.length) s.message = `No sound device found. ${(a.lines || []).join(' ')}`;
            s.devices = a.devices || [];
            s.saved = a.saved || null;
            this.screen.render();
        });
    }

    _tone(name) {
        const s = this.sound;
        if (s.playing) return Promise.resolve();
        s.playing = true;
        s.status = `Playing on ${name}. Can you hear it?`;
        this.screen.render();
        return this.helper.send(`tone ${name} ${s.level}`, SHORT_MS).then((a) => {
            s.playing = false;
            s.results[name] = a.ok && a.played ? 'played' : (a.error || 'failed');
            s.last = name;
            s.status = a.ok && a.played ? `${name}: the tone played. If you heard it, press I heard.` : `${name}: ${s.results[name]}`;
            this.screen.render();
        });
    }

    _toneAll() {
        const s = this.sound;
        if (s.playing) return;
        const devices = s.devices.filter((d) => d.cls !== 'leave');
        s.stop = false;
        const next = (i) => {
            if (i >= devices.length || s.stop) {
                if (!s.stop) s.status = 'All played. Press a device again to hear it alone, then press I heard.';
                this.screen.render();
                return undefined;
            }
            return this._tone(devices[i].name).then(() => {
                s.status = `Played ${i + 1} of ${devices.length}: ${devices[i].name}`;
                this.screen.render();
                return new Promise((res) => setTimeout(res, BETWEEN_TONES_MS));
            }).then(() => next(i + 1));
        };
        next(0);
    }

    _keep() {
        const s = this.sound;
        if (!s.last) return Promise.resolve();
        const name = s.last;
        return this.helper.send(`save ${name}`, SHORT_MS).then((a) => {
            if (a.ok) s.saved = name;
            s.status = a.ok ? `Kept ${name}. The YouTube app uses it from the next video.` : `Could not keep it: ${a.error}`;
            this.screen.render();
        });
    }

    /* ---- the snapshot ---- */

    _probe(label) {
        return this._run(`probe ${label}`, { title: `Sound snapshot: ${label}`, hint: 'Reading how sound moves, for about 20 seconds. It plays nothing and stops nothing.', ms: PROBE_MS, fallback: `Sound snapshot: ${label}` })
            .then((a) => {
                if (a && a.ok) this.snapshot[label] = true;
            });
    }
}

module.exports = { Controller };
