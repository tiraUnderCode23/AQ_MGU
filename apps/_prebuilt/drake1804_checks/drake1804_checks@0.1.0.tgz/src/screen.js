'use strict';
/**
 * The screens on the renderer: the connection, the placement, the page stack over the HMI's host states and their proxies, touch and
 * the dial. src/pages.js makes each frame. The same shape as the YouTube app's src/drawn.js, with less to do, and one thing more:
 *
 * With no layer this still works. The proxies are buttons in the HMI's own list under the layer, so the page's words go on them instead,
 * and the driver scrolls them with the dial. This app is what says what is wrong, and the renderer may be what is wrong.
 *
 * Emits 'page-closed' (page), when the HMI's BACK or the app closed a page, and 'unavailable' (why) as the renderer goes.
 */
const EventEmitter = require('events');
const { RenderClient } = require('./mgu_render_client.js');
const kit = require('./kit_record.js');
const { frame, hit, W, H } = require('./pages.js');

const DEPTHS = 3;
const FPS = 10;
const KEEPALIVE_MS = 1000;              // the renderer hides an app silent for 3 s
const CLOSED_RESHOW_MS = 700;           // a touch outside that left the page where it was
const DIAL_MAX_STEP = 24;               // a bigger jump of the counter is a stale or garbage sample
const PUSHED = ['DREHGEBER_KURZ_GEDRUECKT', 'DREHGEBER_LANG_GEDRUECKT', 1, 2];
const RELEASED = ['KEINE_BETAETIGUNG', 0];
const COUNTER_INVALID = 0xffff;

class Screen extends EventEmitter {
    /**
     * host: { log, appId, model(), act(act), openState(name), closeState(name), hostName(depth), proxyName(depth, i),
     * setText(name, text), show(name, on), proxies (count per depth) }.
     */
    constructor(host, opts) {
        super();
        this.host = host;
        this.log = host.log;
        this.gpu = (opts && opts.client) || new RenderClient(host.appId, this.log, { kit, mode: 'layer' });
        this.gpu.fps(FPS);
        this.rec = new kit.Recorder(W, H);
        this.available = false;
        this.rendererInfo = null;
        this.rendererWhy = 'not connected yet';
        this.stack = [{ page: 'menu' }];
        this.focus = 0;
        this.view = { at: 0, pages: 0, parts: [] };
        this.items = [];
        this.plain = true;
        this.visibleHosts = new Set();
        this.focusLost = false;         // the top host state lost the HMI's focus: a popup
        this.held = false;              // something else is on the screen for now: the colour bars
        this.closedHide = false;
        this.on_ = false;
        this.dirty = false;
        this.sentAt = 0;
        this.keepalive = null;
        this.touch = null;
        this.fccu = null;
        this.ccu = null;
        this.controller = false;
        this.gpu.on('ready', (screen, info) => this._ready(info));
        this.gpu.on('close', () => this._gone('The renderer went away'));
        this.gpu.on('tick', () => { if (this.dirty) this.render(); });
        this.gpu.on('touch', (phase, x, y) => this._touch(phase, x, y));
        this.gpu.on('renderer-error', (e) => this.log.warn(`renderer: ${e}`));
        this.gpu.on('closed', () => {
            this.closedHide = true;
            this._updateShow();
            setTimeout(() => {
                this.closedHide = false;
                this._updateShow();
            }, CLOSED_RESHOW_MS);
        });
        this.gpu.on('ccu', (e) => this._ccu(e));
    }

    connect() { this.gpu.connect(); }

    close() {
        clearInterval(this.keepalive);
        this.gpu.removeAllListeners('close');
        this.gpu.close();
    }

    _ready(info) {
        this.rendererInfo = info;
        if (!info) return this._gone('This renderer is too old: update Renderer in the Store');
        if (info.modes.indexOf('layer') < 0) return this._gone('The renderer offers no layer');
        const box = info.appArea;
        const scale = Math.min(box.w / W, box.h / H);
        this.controller = !!info.controller;
        this.gpu.mode('layer');
        this.gpu.place({ x: box.x, y: box.y, w: box.w, h: box.h, scale, ox: Math.round((box.w - W * scale) / 2), oy: Math.round((box.h - H * scale) / 2) });
        this.rec = new kit.Recorder(W, H, { textScale: scale });
        this.log.info(`renderer: layer ${box.w}x${box.h} at ${box.x},${box.y}, scale ${scale.toFixed(3)}, controller ${this.controller}`);
        this.available = true;
        this.rendererWhy = null;
        this._updateShow();
        return undefined;
    }

    _gone(why) {
        this.available = false;
        this.rendererWhy = why;
        this.touch = null;
        this._updateShow();
        this.render();
        this.emit('unavailable', why);
    }

    top() { return this.stack[this.stack.length - 1].page; }

    _enter() {
        this.focus = 0;
        this.touch = null;
        this.render();
    }

    push(page) {
        const was = this.stack[this.stack.length - 1];
        was.focus = this.focus;
        if (this.stack.length >= DEPTHS) {
            this.stack[DEPTHS - 1] = { page };
        } else {
            this.stack.push({ page });
            this.host.openState(this.host.hostName(this.stack.length));
        }
        this._enter();
    }

    _back() {
        this.focus = this.stack[this.stack.length - 1].focus || 0;
        this.touch = null;
        this.render();
    }

    /* The HMI went back under the page on top: its BACK. */
    _closedTo(depth) {
        if (depth >= this.stack.length) return;
        const closed = this.stack.slice(depth).map((s) => s.page);
        this.stack.length = depth;
        this._back();
        closed.reverse().forEach((page) => this.emit('page-closed', page));
    }

    hostVisible(depth, visible) {
        if (visible) {
            this.visibleHosts.add(depth);
            this._closedTo(depth);
            this.focusLost = false;
            this.dirty = true;
        } else {
            this.visibleHosts.delete(depth);
        }
        this._updateShow();
    }

    hostFocus(depth, focus) {
        if (focus) this._closedTo(depth);
        if (depth === this.stack.length) this.focusLost = !focus;
        this._updateShow();
    }

    proxyFocus(depth, i, value) {
        if (depth === this.stack.length && value) {
            this.focus = this._itemOfProxy(i);
            this.render();
        }
    }

    proxyPress(depth, i) {
        if (depth !== this.stack.length) return;
        const at = this._itemOfProxy(i);
        if (at >= 0 && this.items[at]) {
            this.focus = at;
            this.host.act(this.items[at].act);
        }
    }

    /* The item behind proxy i, or -1 for a row of words on the plain list. Only items with a proxy count; on that list, all of them. */
    _itemOfProxy(i) {
        let n = -1;
        for (let k = 0; k < this.items.length; k++) {
            if ((this.plain || this.items[k].proxy !== false) && ++n === i) return k;
        }
        return -1;
    }

    /* Something else is to be seen on the screen for now: the layer goes, and the page's words are on the plain list under it. */
    hold(on) {
        this.held = on;
        this._updateShow();
        this.render();
    }

    /* A new result: from its first page. */
    showResult() {
        this.view.at = 0;
        this.render();
    }

    turnPage(by) {
        if (!this.view.pages) return;
        this.view.at = (this.view.at + by + this.view.pages) % this.view.pages;
        this.render();
    }

    nextPart() {
        const after = this.view.parts.find((p) => p > this.view.at);
        this.view.at = after === undefined ? 0 : after;
        this.render();
    }

    _shouldShow() {
        return this.available && this.visibleHosts.size > 0 && !this.held && !this.closedHide && !this.focusLost;
    }

    _updateShow() {
        const on = this._shouldShow();
        if (on === this.on_) return;
        this.on_ = on;
        this.touch = null;
        if (!this.available) {
            clearInterval(this.keepalive);
            this.keepalive = null;
            return;
        }
        this.gpu.claim(on ? [{ x: 0, y: 0, w: W, h: H }] : []);
        this.gpu.grab(on && this.controller);
        if (on) this.render(true);
        this.gpu.show(on);
        clearInterval(this.keepalive);
        this.keepalive = on ? setInterval(() => {
            if (Date.now() - this.sentAt >= KEEPALIVE_MS) this.render(true);
        }, KEEPALIVE_MS) : null;
        if (!on) this.render();
    }

    /* The page, on the layer when it shows and on the plain list when not. force: now, whatever the renderer said about being ready. */
    render(force) {
        const drawn = this.on_ || (force && this.available);
        this.plain = !drawn;
        // made even if it cannot go yet: a press must find the items of the page that is up, not of the one before
        const f = frame(this.host.model(), { rec: this.rec, page: this.top(), focus: this.focus, view: this.view, plain: this.plain });
        this.items = f.items;
        this._proxies(f.rows);
        if (drawn && this.gpu.waiting && !force) {
            this.dirty = true;
            return;
        }
        if (drawn) {
            this.gpu.frame(this.rec);
            this.sentAt = Date.now();
        }
        this.dirty = false;
    }

    /* Only what changed goes to the HMI: the host writes a cell only when its value changed. */
    _proxies(rows) {
        const depth = this.stack.length;
        const labels = this.plain ? this.items.map((it) => it.label).concat(rows) : this.items.filter((it) => it.proxy !== false).map((it) => it.label);
        const n = this.host.proxies[depth - 1] || 0;
        for (let i = 0; i < n; i++) {
            const name = this.host.proxyName(depth, i);
            if (labels[i] !== undefined) this.host.setText(name, labels[i]);
            this.host.show(name, labels[i] !== undefined);
        }
    }

    /* ---- touch ---- */

    _touch(phase, x, y) {
        if (phase === 'down') {
            this.touch = { item: hit(this.items, x, y) };
            return;
        }
        if (phase === 'move') return;
        const t = this.touch;
        this.touch = null;
        if (!t || t.item < 0) return;
        const it = this.items[t.item];
        if (!it || !(x >= it.x && x < it.x + it.w && y >= it.y - 8 && y < it.y + it.h + 8)) return;
        if (it.proxy !== false) this.focus = t.item;
        this.host.act(it.act);
        this.render();
    }

    /* ---- the dial ---- */

    /* A FrontCCU.statusRotaryEncoderState sample. On the report's one proxy the HMI's focus stays put, so this is what turns the pages. */
    frontCcu(s) {
        const last = this.fccu;
        const op = s && s.frontRotaryEncoderOperation;
        const push = s && s.frontRotaryEncoderPushButton;
        this.fccu = {
            knob: typeof op === 'number' && op !== COUNTER_INVALID ? op : (last ? last.knob : COUNTER_INVALID),
            press: PUSHED.indexOf(push) >= 0 ? true : RELEASED.indexOf(push) >= 0 ? false : !!(last && last.press)
        };
        if (last && !this.controller && this.top() === 'report' && this.on_) this._dial(last.knob, this.fccu.knob, false);
    }

    /* The dial through the renderer's controller gate. */
    _ccu(e) {
        const last = this.ccu;
        this.ccu = e;
        if (last) this._dial(last.knob, e.knob, e.press && e.press !== last.press && e.seq !== last.seq);
    }

    _dial(from, to, pushed) {
        if (!this.on_) return;
        const steps = ((to - from + 0x18000) % 0x10000) - 0x8000;
        const moved = to !== COUNTER_INVALID && from !== COUNTER_INVALID && steps !== 0 && Math.abs(steps) <= DIAL_MAX_STEP;
        if (moved) {
            if (this.top() === 'report') {
                this.turnPage(steps > 0 ? 1 : -1);
            } else {
                this.focus = Math.max(0, Math.min(this.items.length - 1, this.focus + steps));
                this.render();
            }
        }
        if (pushed && this.items[this.focus]) this.host.act(this.items[this.focus].act);
    }
}

module.exports = { Screen, DEPTHS };
