'use strict';
/* What src/kit_fonts.js asks of the display language: this app has one font for every language, Inter. */
module.exports = { font: () => null };
