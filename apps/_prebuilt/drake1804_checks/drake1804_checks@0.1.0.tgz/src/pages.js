'use strict';
/**
 * The screens: one frame of a page from the model, and what on it can be pressed, in focus order. No I/O.
 *
 *   frame(model, { rec, page, focus, view, plain }) -> { items, rows }
 *
 * Laid out on the logical 1790 x 638 of iDrive 7's app area. page: 'menu', 'report', 'sound' or 'snapshot'. rec: a kit Recorder, reset here.
 * view: { at, pages, parts }, the report's page; at is kept by the caller, the others set here.
 * items: { x, y, w, h, r, label, act, proxy }; proxy false: touch only. rows: the text of the page, for the HMI's own list when there is no layer
 * (plain: true). Then pages are cut for that list instead: the app must still be able to say what is wrong when the renderer is what is wrong.
 *
 * The report is meant to be photographed: small text, as much of it as fits, each page numbered. Regular at 23 and semibold at 25 are sizes the fonts are baked at.
 */
const W = 1790;
const H = 638;
const C = { bg: '#0B0D10', panel: '#1A1E25', raised: '#2A2F39', text: '#F5F6F8', soft: '#C9CED6', dim: '#AEB4BE', accent: '#FF5C4D', warn: '#F5B83D', good: '#5FD38A', white: '#FFFFFF' };
const BOLD = { font: 'bold' };
const MARGIN = 24;
const FOCUS_GAP = 8;
const FOCUS_WIDTH = 5;

const TEXT_SIZE = 23;
const ROW_H = 27;
const TEXT_TOP = 62;
const ROWS = 21;
const SIDE_W = 200;
const SIDE_X = W - MARGIN - SIDE_W;
const TEXT_W = SIDE_X - MARGIN - 24;
const PLAIN_WIDTH = 64;     // characters on a row of the HMI's list
const PLAIN_ROWS = 34;
const CONTINUED = '    ';
const HEADING = '== ';

const CARD_W = 564;
const CARD_H = 262;
const CARD_Y = 72;
const DEVICE_ROWS = 5;

const CARDS = [
    { title: 'Run all checks', words: 'Reads the logs and how things are set up, in up to a minute. Then take a photo of every page, in order.', act: { do: 'report' } },
    { title: 'Video test', words: 'Colour bars for 45 seconds, then the frame rate. Say afterwards whether you saw the bars.', act: { do: 'video' } },
    { title: 'Player test', words: 'Searches YouTube and plays a video out of sight for 30 seconds. Needs the car online.', act: { do: 'player' } },
    { title: 'Sound test', words: 'Quiet tones on each sound device, one at a time. Parked only: the head unit may restart.', act: { do: 'sound' } },
    { title: 'Sound snapshot', words: 'Records how sound moves in CarPlay: idle, playing and paused. About 20 seconds each.', act: { do: 'snapshot' } },
    { title: 'Last results', words: 'Shows the last results again.', act: { do: 'last' } }
];
const STEPS = [
    { label: 'idle', title: '1. Nothing playing', words: 'Connect the phone to CarPlay, with nothing playing. Then press here.' },
    { label: 'playing', title: '2. Music playing', words: 'Start music in CarPlay at a low volume and wait 20 seconds. Then press here.' },
    { label: 'after', title: '3. Paused', words: 'Pause the music and wait 20 seconds. Then press here.' }
];

/* A long line as rows that fit, cut at a space where it can be. */
function wrapLine(text, measure, maxW) {
    const out = [];
    let rest = String(text);
    let first = true;
    while (rest || first) {
        const probe = first ? rest : CONTINUED + rest;
        if (measure(probe) <= maxW) {
            out.push(probe);
            break;
        }
        let lo = first ? 1 : CONTINUED.length + 1, hi = probe.length;
        while (lo < hi) {
            const mid = (lo + hi + 1) >> 1;
            if (measure(probe.slice(0, mid)) <= maxW) lo = mid;
            else hi = mid - 1;
        }
        const space = probe.lastIndexOf(' ', lo);
        const cut = space > lo * 0.6 ? space : lo;
        out.push(probe.slice(0, cut).replace(/\s+$/, ''));
        rest = probe.slice(cut).replace(/^\s+/, '');
        first = false;
    }
    return out;
}

/* A result as pages, as few as will hold it: each photo is work. The parts run on, under a heading of their own, but for the first, which has
 * its page to itself: with a result of several parts that is the summary, and it may be the only photo needed. parts: the page each part starts on. */
function paginate(result, measure, maxW, perPage) {
    const pages = [], parts = [];
    let rows = [], titles = [];
    const flush = () => {
        if (!rows.length) return;
        pages.push({ title: titles.join(', '), rows });
        rows = [];
        titles = [];
    };
    result.sections.forEach((s, i) => {
        if (i === 1) flush();
        // a heading stays with at least two of its rows
        if (rows.length && rows.length > perPage - 3) flush();
        parts.push(pages.length);
        titles.push(s.title);
        // at the top of a page the page's own title says it
        if (rows.length) rows.push(`${HEADING}${s.title}`);
        (s.lines.length ? s.lines : ['Nothing here']).forEach((l) => wrapLine(l, measure, maxW).forEach((row) => {
            if (rows.length === perPage) {
                flush();
                titles.push(`${s.title} (continued)`);
            }
            rows.push(row);
        }));
    });
    flush();
    return { pages, parts };
}

function layout(result, rec, plain) {
    const key = plain ? 'plain' : 'drawn';
    if (!result.layouts) Object.defineProperty(result, 'layouts', { value: {}, enumerable: false });
    if (!result.layouts[key]) {
        result.layouts[key] = plain ? paginate(result, (s) => s.length, PLAIN_WIDTH, PLAIN_ROWS) :
            paginate(result, (s) => rec.textWidth(s, TEXT_SIZE), TEXT_W, ROWS);
    }
    return result.layouts[key];
}

function wrapWords(rec, text, width, size, font) {
    const out = [];
    let line = '';
    String(text).split(/\s+/).forEach((w) => {
        const next = line ? `${line} ${w}` : w;
        if (line && rec.textWidth(next, size, { font }) > width) {
            out.push(line);
            line = w;
        } else {
            line = next;
        }
    });
    if (line) out.push(line);
    return out;
}

function fit(rec, text, width, size, font) {
    const s = String(text);
    if (rec.textWidth(s, size, { font }) <= width) return s;
    let lo = 0, hi = s.length;
    while (lo < hi) {
        const mid = (lo + hi + 1) >> 1;
        if (rec.textWidth(`${s.slice(0, mid)}...`, size, { font }) <= width) lo = mid;
        else hi = mid - 1;
    }
    return `${s.slice(0, lo)}...`;
}

function button(rec, items, b) {
    const size = b.size || 33;
    rec.roundRect(b.x, b.y, b.w, b.h, 20, C.raised);
    wrapWords(rec, b.text, b.w - 24, size, 'bold').slice(0, 2).forEach((line, i, all) => {
        const y = b.y + b.h / 2 + size * 0.36 + (i - (all.length - 1) / 2) * (size + 6);
        rec.text(fit(rec, line, b.w - 24, size, 'bold'), b.x + b.w / 2, y, size, C.text, { font: 'bold', align: 'center' });
    });
    items.push({ x: b.x, y: b.y, w: b.w, h: b.h, r: 20, label: b.text, act: b.act, proxy: b.proxy });
}

function card(rec, items, c, x, y, h, extra) {
    rec.roundRect(x, y, CARD_W, h, 20, C.panel);
    rec.text(c.title, x + 24, y + 52, 33, C.text, BOLD);
    wrapWords(rec, c.words, CARD_W - 48, TEXT_SIZE).slice(0, 6).forEach((line, i) => rec.text(line, x + 24, y + 96 + i * ROW_H, TEXT_SIZE, C.soft));
    if (extra) rec.text(extra, x + 24, y + h - 24, 25, C.good, BOLD);
    items.push({ x, y, w: CARD_W, h, r: 20, label: c.title, act: c.act });
}

function helperWords(m) {
    if (m.helper.up) return { text: `Helper ready ${m.helper.version || ''}`.trim(), color: C.good };
    return { text: 'Helper not running: restart the head unit, or install it in the Store', color: C.warn };
}

function menu(rec, m) {
    const items = [];
    rec.text(`YouTube Checks ${m.version}`, MARGIN, 46, 33, C.text, BOLD);
    const h = helperWords(m);
    rec.text(h.text, W - MARGIN, 46, 25, h.color, { font: 'bold', align: 'right' });
    CARDS.forEach((c, i) => card(rec, items, c, MARGIN + (i % 3) * (CARD_W + MARGIN), CARD_Y + Math.floor(i / 3) * (CARD_H + MARGIN), CARD_H));
    return { items, rows: [h.text] };
}

function rowColor(row) {
    if (/^FAIL\b/.test(row)) return C.accent;
    if (/^WARN\b/.test(row)) return C.warn;
    if (/^OK\b/.test(row)) return C.good;
    return C.soft;
}

function report(rec, m, o) {
    const items = [];
    if (m.busy) {
        rec.text(m.busy.title, MARGIN, 90, 44, C.text, BOLD);
        const hint = wrapWords(rec, m.busy.hint || '', W - 2 * MARGIN, 31);
        hint.forEach((line, i) => rec.text(line, MARGIN, 150 + i * 42, 31, C.soft));
        const words = `Working... ${m.busy.seconds} s`;
        rec.text(words, MARGIN, 150 + hint.length * 42 + 30, 31, C.warn);
        return { items, rows: [m.busy.title].concat(hint, [words]) };
    }
    if (!m.result) {
        rec.text('Nothing has run yet', MARGIN, 90, 44, C.text, BOLD);
        rec.text('Go back, and choose Run all checks', MARGIN, 150, 31, C.soft);
        return { items, rows: ['Nothing has run yet'] };
    }
    const { pages, parts } = layout(m.result, rec, o.plain);
    const view = o.view;
    view.pages = pages.length;
    view.parts = parts;
    view.at = Math.max(0, Math.min(pages.length - 1, view.at || 0));
    const page = pages[view.at];
    const where = `Page ${view.at + 1} of ${pages.length}   ${m.result.at || ''}   Checks ${m.version}`;
    const heading = page.title;
    if (!o.plain) {
        const whereW = rec.textWidth(where, 25, BOLD);
        rec.text(fit(rec, heading, TEXT_W - whereW - 24, 25, 'bold'), MARGIN, 40, 25, C.text, BOLD);
        rec.text(where, SIDE_X - 24, 40, 25, C.dim, { font: 'bold', align: 'right' });
        page.rows.forEach((row, i) => {
            const y = TEXT_TOP + 20 + i * ROW_H;
            if (row.startsWith(HEADING)) rec.text(row.slice(HEADING.length), MARGIN, y, 25, C.text, BOLD);
            else rec.text(row, MARGIN, y, TEXT_SIZE, rowColor(row));
        });
    }
    const step = 194;
    button(rec, items, { x: SIDE_X, y: 40, w: SIDE_W, h: 170, text: 'Next page', act: { do: 'page', by: 1 } });
    // one proxy only, as on YouTube's player: the HMI's focus stays put, so that the dial can turn the pages
    button(rec, items, { x: SIDE_X, y: 40 + step, w: SIDE_W, h: 170, text: 'Previous', act: { do: 'page', by: -1 }, proxy: false });
    button(rec, items, { x: SIDE_X, y: 40 + 2 * step, w: SIDE_W, h: 170, text: 'Next part', act: { do: 'part' }, proxy: false });
    return { items, rows: [`${heading}, page ${view.at + 1} of ${pages.length}`].concat(page.rows) };
}

function sound(rec, m) {
    const items = [];
    const s = m.sound;
    rec.text('Sound test', MARGIN, 44, 33, C.text, BOLD);
    const warn = 'Parked only: the head unit may restart. Select CarPlay as the source and pause the music first.';
    rec.text(warn, MARGIN, 80, TEXT_SIZE, C.warn);
    const usable = s.devices.filter((d) => d.cls !== 'leave');
    const rows = [warn];
    const topY = 104;
    const first = s.page * DEVICE_ROWS;
    usable.slice(first, first + DEVICE_ROWS).forEach((d, i) => {
        const y = topY + i * 96;
        const result = s.results[d.name] || '';
        const label = `${d.cls} ${d.name}${result ? `: ${result}` : ''}`;
        rec.roundRect(MARGIN, y, 1282, 84, 16, C.raised);
        const name = fit(rec, `${d.cls === 'try' ? 'Likely' : 'Maybe'}   ${d.name}`, 780, 25, 'bold');
        rec.text(name, MARGIN + 24, y + 51, 25, C.text, BOLD);
        rec.text(fit(rec, result, 440, TEXT_SIZE), MARGIN + 1258, y + 50, TEXT_SIZE, result === 'played' ? C.good : C.accent, { align: 'right' });
        items.push({ x: MARGIN, y, w: 1282, h: 84, r: 16, label, act: { do: 'tone', name: d.name } });
    });
    if (!usable.length) {
        const empty = s.message || 'Looking for sound devices...';
        wrapWords(rec, empty, 1282, 31).forEach((line, i) => rec.text(line, MARGIN, topY + 40 + i * 42, 31, C.soft));
        rows.push(empty);
    }
    const x = 1330, w = 436, h = 103, step = 127;
    if (usable.length) {
        button(rec, items, { x, y: topY, w, h, size: 25, text: 'Test all', act: { do: 'toneAll' } });
        button(rec, items, { x, y: topY + step, w, h, size: 25, text: `Level ${s.level} dB`, act: { do: 'level' } });
        if (s.last) button(rec, items, { x, y: topY + 2 * step, w, h, size: 25, text: `I heard ${s.last}: keep it`, act: { do: 'keep' } });
        if (usable.length > DEVICE_ROWS) button(rec, items, { x, y: topY + 3 * step, w, h, size: 25, text: 'More devices', act: { do: 'moreDevices' } });
    }
    const status = s.status || `Saved: ${s.saved || 'none, the player guesses'}. Press a device to play a tone on it.`;
    rec.text(fit(rec, status, W - 2 * MARGIN, TEXT_SIZE), MARGIN, H - 12, TEXT_SIZE, s.status ? C.text : C.dim);
    rows.push(status);
    return { items, rows };
}

function snapshot(rec, m) {
    const items = [];
    rec.text('Sound snapshot', MARGIN, 44, 33, C.text, BOLD);
    const words = 'Reads how sound moves, in three steps. It plays nothing and stops nothing. If the car\'s internet comes from this phone over USB, turn that off first.';
    const lines = wrapWords(rec, words, W - 2 * MARGIN, 25);
    lines.forEach((line, i) => rec.text(line, MARGIN, 88 + i * 32, 25, C.soft));
    STEPS.forEach((step, i) => {
        const act = { do: 'probe', label: step.label };
        card(rec, items, { title: step.title, words: step.words, act }, MARGIN + i * (CARD_W + MARGIN), 190, 300, m.snapshot[step.label] ? 'Done' : '');
    });
    rec.text('Each step shows its results. Photograph them, then go back for the next step.', MARGIN, 540, 25, C.dim);
    return { items, rows: lines };
}

const PAGES = { menu, report, sound, snapshot };

function frame(m, o) {
    const rec = o.rec;
    rec.reset();
    rec.clear([0, 0, 0, 0]);
    rec.fillRect(0, 0, W, H, C.bg);
    const out = PAGES[o.page](rec, m, o);
    const f = out.items[o.focus];
    if (f && (f.proxy !== false || o.plain)) {
        rec.strokeRoundRect(f.x - FOCUS_GAP, f.y - FOCUS_GAP, f.w + 2 * FOCUS_GAP, f.h + 2 * FOCUS_GAP, f.r + FOCUS_GAP, FOCUS_WIDTH, C.white);
    }
    return out;
}

const inside = (r, x, y) => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h;

function hit(items, x, y) {
    for (let i = items.length - 1; i >= 0; i--) {
        if (inside(items[i], x, y)) return i;
    }
    return -1;
}

module.exports = { frame, hit, paginate, wrapLine, W, H, ROWS, TEXT_W, TEXT_SIZE, PLAIN_WIDTH, PLAIN_ROWS, DEVICE_ROWS };
