'use strict';
/**
 * What the app does, without the HMI: the model the screens draw, and what a press means. src/youtube.js ties it to the
 * oap-sdk, src/drawn.js to the renderer, src/player_client.js to the player; each comes in here as a stand-in in the tests.
 *
 * While the video does not show (the HMI's popup, HOME, the reversing camera) the player pauses, and goes on when it
 * shows again: the Atom's CPU has better things to do than decode what nobody sees.
 *
 * Signed in, the tabs are Home, Subscriptions, Playlists, Liked and History. Signed out there is only History: Home needs an account.
 * The tokens stay in the player tool; this only hears who is signed in, and asks it for lists.
 */
const { parseInput, statusOf, MAX_ROWS, CARDS_SHOWN } = require('./ui.js');

const STATUS_POLL_MS = 500;
const SUB_LEAD_S = STATUS_POLL_MS / 2000;   // a status comes twice a second: half that ahead, a line is never far from the picture, with no timer of its own
const START_TICK_MS = 200;          // while there is no picture yet, so a start that works can't look like one that hangs
const SPIN_DEG = 54;
const MAX_THUMBS = 40;              // decoded thumbnails held: 40 x 320 x 180 x 4 is 9.2 MB
const THUMBS_AHEAD = 2;             // past the screen's edge, so that the next card is there when the dial gets to it
const SAVE_POSITION_S = 15;
const FEED_FRESH_MS = 5 * 60 * 1000;    // a tab opened again within this shows what it has; pressed again while on show, it is fetched now
const KEEP_WATCHING = 3;            // unfinished videos at the front of Home
const SIGNIN_POLL_MS = 5000;
const LOGS_TICK_MS = 5000;

class Controller {
    /**
     * deps: { log, player (PlayerClient), data (AppData), appLog (AppLog), drawn (Drawn), spell(title) -> Promise of the text or null,
     *         makeImage(w, h, data), dropImage(img) }
     */
    constructor(deps) {
        Object.assign(this, deps);
        this.m = {
            account: null,
            configured: false,
            tab: 'history',
            feeds: {},
            list: null,
            recent: this.data.recent,
            history: this.data.history,
            settings: this.data.settings,
            settingsNote: '',
            logs: null,                 // while Send logs online is on: { hours, id, sent, note }
            signin: null,
            player: null,
            thumbs: (id) => this._thumb(id)
        };
        this.thumbs = new Map();        // id -> { img } once decoded, { img: null } while on its way or refused
        this.listSeq = 0;
        this.feedSeq = {};
        this.poll = null;
        this.ticker = null;
        this.stateSeq = 0;              // raised each time this file says what the player is doing: see _pollStatus
        this.autoPaused = false;
        this.driverPaused = false;
        this.shown = false;
        this.onScreen = true;
        this.savedAt = 0;
        this.current = null;            // the video on the player page: { id?, target, title, channel, duration }
        this.subs = null;               // its subtitles, once they are wanted: { state: 'loading', 'on', 'none' or 'failed', cues }
        this.signinTimer = null;
        this.signinEnds = 0;
        this.signinSeq = 0;
        this.logsTimer = null;
        this.logsHanding = false;

        this.player.on('connected', () => this._tellPlayer());
        this.drawn.on('shown', (on) => { this.shown = on; this._showChanged(); });
        this.drawn.on('on-screen', (on) => { this.onScreen = on; this._showChanged(); });
        this.drawn.on('page-closed', (page) => this._pageClosed(page));
        this.drawn.on('scrolled', () => this._fetchThumbs());
    }

    start() { this.player.connect(); }

    model() { return this.m; }

    stop() {
        clearInterval(this.poll);
        clearInterval(this.ticker);
        clearInterval(this.logsTimer);
        clearTimeout(this.signinTimer);
        this._rememberPosition();
    }

    /* The player is there, at the app's start or after it restarted, and knows nothing. An app that was playing asks again from
     * where it was; one that was not stops whatever a crashed app of ours left decoding with nobody watching. */
    _tellPlayer() {
        this.player.cmd(`quality ${this.data.settings.quality}`);
        this.player.cmd(`instance ${this.data.settings.instance || '-'}`);
        this.player.cmd('sound loud');
        this._tellLogs();
        this._loadAccount();
        const p = this.m.player;
        if (!p || !this.current) {
            this.player.cmd('stop');
            return;
        }
        this._startOver('buffering');
        this.drawn.render();
        this.player.cmd(`play ${this.current.target}${p.pos ? ` ${p.pos.toFixed(1)}` : ''}`);
        this._holdIfHidden();
        if (this.driverPaused && this._showing()) this.player.cmd('pause');
    }

    /* ---- who is signed in, and the tabs ---- */

    _loadAccount() {
        return this.player.slow('account').then((a) => {
            if (!a.ok) return;
            this.m.configured = !!a.configured;
            const was = this.m.account && this.m.account.name;
            this.m.account = a.signedIn ? { name: a.name } : null;
            if (a.signedIn && !was) this._showTab('home');
            else if (!a.signedIn) this._signedOutNow();
            else this.drawn.render();
        });
    }

    _signedOutNow() {
        this.m.account = null;
        this.m.feeds = {};
        this.m.tab = 'history';
        this.drawn.render();
        this._fetchThumbs();
    }

    _showTab(tab) {
        this.m.tab = tab;
        this.drawn.scroll.list = 0;
        this.drawn.render();
        this._loadFeed(tab);
        this._fetchThumbs();
    }

    /* The tab on show, pressed again: fetched now. The player's resolver keeps a list ten minutes, and nothing else gets past that. */
    _refreshTab() {
        if (this.m.tab === 'history') return undefined;
        return this._loadFeed(this.m.tab, true);
    }

    /* fresh: the driver asked, so neither this nor the player's resolver answers with what it has kept. A list from a time still to come by
     * the car's clock is old too: the clock can go back. The cards stay while the next ones come, and if those don't. */
    _loadFeed(tab, fresh) {
        if (tab === 'history' || !this.m.account) return undefined;
        const have = this.m.feeds[tab];
        const age = have ? Date.now() - have.at : 0;
        if (have && (have.loading ? !fresh || have.fresh : !fresh && age >= 0 && age < FEED_FRESH_MS)) return undefined;
        const seq = this.feedSeq[tab] = (this.feedSeq[tab] || 0) + 1;
        const rows = have ? have.rows : [];
        this.m.feeds[tab] = { rows, loading: true, fresh: !!fresh, error: '', at: have ? have.at : 0 };
        this.drawn.render();
        return this.player.slow(`feed ${fresh ? 'fresh ' : ''}${tab}`).then((a) => {
            if (seq !== this.feedSeq[tab]) return;
            if (a.ok) {
                const got = a.rows || [];
                const first = got[0] ? got[0].id || got[0].playlist : '';
                this.log.info(`feed ${tab}: ${got.length} row${got.length === 1 ? '' : 's'}${first ? `, first ${first}` : ''}${fresh ? ', fresh' : ''}`);
                this.m.feeds[tab] = { rows: tab === 'home' ? this._homeRows(got) : got, loading: false, error: '', at: a.at > 0 ? a.at * 1000 : Date.now() };
            } else if (a.reason === 'signedout') {
                this._signedOutNow();
                return;
            } else {
                this.log.warn(`feed ${tab}: ${a.error}`);
                this.m.feeds[tab] = { rows, loading: false, error: a.error || 'That list did not load', at: have ? have.at : 0 };
            }
            this.drawn.render();
            this._fetchThumbs();
        });
    }

    /* Home: what is unfinished first, then the player's list. */
    _homeRows(rows) {
        const unfinished = this.data.history.filter((h) => h.pos > 0 && h.duration > 0).slice(0, KEEP_WATCHING).map((h) => {
            const left = h.duration - h.pos;
            return Object.assign({}, h, { left: h.pos / h.duration, meta: `Keep watching  ·  ${fmtLeft(left)} left` });
        });
        const ids = new Set(unfinished.map((h) => h.id));
        return unfinished.concat(rows.filter((r) => !ids.has(r.id)));
    }

    /* ---- presses ---- */

    act(act) {
        switch (act.do) {
        case 'searchPage': return this._searchPage();
        case 'type': return this._askSearch();
        case 'query': return this.search(act.words);
        case 'tab': return act.tab === this.m.tab ? this._refreshTab() : this._showTab(act.tab);
        case 'reload': return this._reload();
        case 'settings':
            this.m.settingsNote = '';
            this._askLogs();
            return this.drawn.push('settings');
        case 'open': return this.open(act.video);
        case 'playlist': return this._openPlaylist(act.row);
        case 'playpause': return this._playPause();
        case 'retry': return this._retry();
        case 'seekby': return this._seekBy(act.by);
        case 'seekTo': return this._seekTo(act.at);
        case 'leave': return this.drawn.pop();
        case 'quality': return this._setQuality(act.q);
        case 'subtitles': return this._toggleSubs();
        case 'server': return this._askServer();
        case 'logs': return this._toggleLogs();
        case 'clear': return this._clearHistory();
        case 'signin': return this._signInPage();
        case 'signinStart': return this._signInStart();
        case 'signinHome': return this._signInHome();
        case 'signout': return this._signOut();
        default: this.log.warn(`unknown action ${act.do}`);
        }
        return undefined;
    }

    _spell(title) {
        this.drawn.suspend(true);
        return Promise.resolve().then(() => this.spell(title))
            .catch((err) => {
                this.log.warn(`speller: ${err && err.message}`);
                return null;
            })
            .then((text) => {
                this.drawn.suspend(false);
                return text;
            });
    }

    _searchPage() {
        this.m.recent = this.data.recent;
        this.drawn.push('search');
    }

    _askSearch() {
        return this._spell('Search YouTube').then((text) => {
            const input = parseInput(text);
            if (!input) return undefined;
            if (input.kind === 'link') return this.open({ target: input.target });
            return this.search(input.query);
        });
    }

    /* The results take the place of the search page, so BACK goes to where the search began. */
    search(query) {
        const seq = ++this.listSeq;
        this.data.addRecent(query);
        this.m.recent = this.data.recent;
        this.m.list = { title: query, rows: [], loading: true, error: '' };
        this._showList();
        return this.player.slow(`search ${query}`).then((a) => {
            if (seq !== this.listSeq) return;
            this.m.list = a.ok ? { title: query, rows: a.results || [], loading: false, error: '' } :
                { title: query, rows: [], loading: false, error: a.error || 'The search failed' };
            this.drawn.render();
            this._fetchThumbs();
        });
    }

    _openPlaylist(row, fresh) {
        const seq = ++this.listSeq;
        this.m.list = { title: row.title, playlist: row.playlist, rows: [], loading: true, error: '' };
        this._showList();
        return this._loadPlaylist(seq, row, fresh);
    }

    _loadPlaylist(seq, row, fresh) {
        return this.player.slow(`feed ${fresh ? 'fresh ' : ''}playlist:${row.playlist}`).then((a) => {
            if (seq !== this.listSeq) return;
            this.m.list = a.ok ? { title: row.title, playlist: row.playlist, rows: a.rows || [], loading: false, error: '' } :
                { title: row.title, playlist: row.playlist, rows: [], loading: false, error: a.error || 'That list did not load' };
            this.drawn.render();
            this._fetchThumbs();
        });
    }

    _showList() {
        const top = this.drawn.top();
        if (top === 'search' || top === 'results') this.drawn.replace('results');
        else this.drawn.push('results');
        this.drawn.scroll.list = 0;
        this.drawn.render();
    }

    /* "Try again" where a list failed: fetched now, whatever was kept. */
    _reload() {
        if (this.drawn.top() === 'results' && this.m.list) {
            if (this.m.list.playlist) return this._openPlaylist({ playlist: this.m.list.playlist, title: this.m.list.title }, true);
            return this.search(this.m.list.title);
        }
        return this._loadFeed(this.m.tab, true);
    }

    /* ---- thumbnails: asked for one at a time, and only those on the screen or about to be. One that is not in the player's cache costs
     * a start of Python and of ffmpeg on the CPU the video needs, so there are none while a video plays or nobody can see them. ---- */


    _rows() {
        if (this.drawn.top() === 'results' && this.m.list) return this.m.list.rows || [];
        if (this.m.tab === 'history') return this.m.history || [];
        const feed = this.m.feeds[this.m.tab];
        return feed ? feed.rows || [] : [];
    }

    _thumb(id) {
        const t = this.thumbs.get(id);
        return t ? t.img : null;
    }

    /* The rail draws no more than these. */
    _railRows() {
        return this._rows().slice(0, MAX_ROWS);
    }

    _nextThumb() {
        const page = this.drawn.top();
        if (!this.shown || !this.onScreen || (page !== 'browse' && page !== 'results')) return undefined;
        const top = this.drawn.scroll.list || 0;
        return this._railRows().slice(Math.floor(top), Math.ceil(top + CARDS_SHOWN) + THUMBS_AHEAD).find((r) => {
            const id = r.thumb || r.id;
            return id && !this.thumbs.has(id);
        });
    }

    _fetchThumbs() {
        if (this.fetching) return;
        const row = this._nextThumb();
        if (!row) return;
        this.fetching = true;
        const id = row.thumb || row.id;
        const slot = { img: null };
        this.thumbs.set(id, slot);
        this.player.slow(`thumb ${id}`).then((a) => {
            this.fetching = false;
            /* No internet, or the player is away. The next would only fail the same way, each one starting Python to find that out, so
             * it waits for the list to move or open again. Only a picture YouTube says it hasn't got is never asked for again. */
            if (!a.ok && a.reason !== 'unavailable' && a.reason !== 'badlink') {
                this.thumbs.delete(id);
                return;
            }
            const data = a.ok ? Buffer.from(a.rgba || '', 'base64') : null;
            if (data && data.length === a.w * a.h * 4) {
                slot.img = this.makeImage(a.w, a.h, data);
                this._evictThumbs();
                this.drawn.render();
            }
            this._fetchThumbs();
        });
    }

    _evictThumbs() {
        if (this.thumbs.size <= MAX_THUMBS) return;
        const keep = new Set(this._railRows().map((r) => r.thumb || r.id));
        for (const [id, t] of this.thumbs) {
            if (this.thumbs.size <= MAX_THUMBS) break;
            if (!keep.has(id)) {
                if (t.img) this.dropImage(t.img);
                this.thumbs.delete(id);
            }
        }
    }

    /* ---- the player page ---- */

    /* video: a row { id, title, channel, duration }, or { target } for a link typed in. */
    open(video) {
        const target = video.target || video.id;
        const start = video.id ? this.data.startOf(video.id) : 0;
        this.current = Object.assign({}, video, { target });
        this.m.player = { title: video.title || '', channel: video.channel || '', pos: start, dur: video.duration || 0, online: true, turn: 0 };
        this._startOver('resolving');
        this.subs = null;
        this._followSubs();
        this.autoPaused = false;
        this.driverPaused = false;
        this.savedAt = 0;
        if (video.id) this.data.remember({ id: video.id, title: video.title, channel: video.channel, duration: video.duration });
        this.drawn.push('player');
        this._startPolling();
        return this._play(start);
    }

    _play(at) {
        const said = this.player.cmd(`play ${this.current.target}${at ? ` ${at.toFixed(1)}` : ''}`).then((a) => {
            if (!a.ok && this.m.player) {
                this.m.player.state = 'error';
                this.m.player.error = a.error;
                this.drawn.render();
            }
        });
        this._holdIfHidden();
        return said;
    }

    _showing() { return this.shown && this.onScreen; }

    /* Said right after whatever starts the player. With the video out of sight nothing looks again when the first frames come, so it would
     * play until the camera goes. Held at the first frame, it goes on when it shows again, unless the driver paused it. */
    _holdIfHidden() {
        if (this._showing()) return;
        this.autoPaused = !this.driverPaused;
        this.player.cmd('pause');
    }

    /* Nothing of this play has shown yet. */
    _startOver(state) {
        const p = this.m.player;
        this.stateSeq++;
        p.state = state;
        p.error = '';
        p.frames = 0;
        p.wait = 0;
        p.stage = '';
        this._stage(state);
    }

    /* A start moving on to its next part is progress: "taking longer than usual" counts from here. A hold and a time with no internet
     * are parts of their own, so neither what YouTube asks for nor a tunnel counts, and the player gets its time once the internet is back. */
    _stage(stage) {
        const p = this.m.player;
        if (stage === p.stage) return;
        p.stage = stage;
        p.since = Date.now();
        p.waited = 0;
    }

    _startPolling() {
        clearInterval(this.poll);
        clearInterval(this.ticker);
        this.poll = setInterval(() => this._pollStatus(), STATUS_POLL_MS);
        this.ticker = setInterval(() => this._tick(), START_TICK_MS);
    }

    _tick() {
        const p = this.m.player;
        const s = statusOf(p);
        if (!s) return;
        p.waited = (Date.now() - p.since) / 1000;
        if (s.idle || s.spins) p.turn = (p.turn + SPIN_DEG) % 360;
        /* over a lost stream's picture nothing turns: it is drawn again only for new words */
        if (s.idle || s.spins || statusOf(p).words !== s.words) this.drawn.render();
    }

    _pollStatus() {
        if (!this.current) return undefined;
        const seq = this.stateSeq;
        return this.player.cmd('status').then((s) => {
            /* The line keeps its order, so this was answered before whatever has been said to the player since it was asked. Taken as
             * the truth it undoes that: a 'paused' from before a resume, then reverse gear before the next status, and _showChanged
             * finds nothing to pause while the video plays on behind the camera. The next status is at most a poll away. */
            if (seq !== this.stateSeq) return;
            const p = this.m.player;
            if (!p || !this.current) return;
            if (!s.ok) {
                /* the service restarts by itself, and connecting again plays on (_tellPlayer) */
                if (s.unreachable && p.state !== 'stalled') {
                    this.log.warn('the player cannot be reached');
                    p.state = 'stalled';
                    this._stage('stalled');
                    this.drawn.render();
                }
                return;
            }
            /* the player has stopped before: a status from before this play's first answer changes nothing */
            if (s.state === 'idle') return;
            const shownBefore = `${p.state}|${Math.floor(p.pos)}|${p.dur}|${p.error}|${p.title}|${p.audio}|${p.audioDevice}|${p.audioError}|${p.online}|${Math.ceil(p.wait)}|${p.subs}|${p.subLine}|${p.w}x${p.h}`;
            if (s.state !== p.state) this.log.info(`player: ${s.state} at ${Number(s.pos).toFixed(1)}${s.error ? `: ${s.error}` : ''}`);
            if (s.audio !== p.audio || s.audioError !== p.audioError) {
                this.log.info(`sound: ${s.audio} ${s.audioDevice || ''} ${s.audioError || ''}`);
            }
            p.state = s.state;
            p.pos = s.pos;
            p.dur = s.dur || p.dur;
            p.frames = s.frames;
            p.wait = s.wait || 0;       // a player older than 0.1.10 doesn't say
            this._stage(s.online === false ? 'offline' : p.wait > 0 ? 'held' : s.state);
            p.live = s.live;
            p.online = s.online;
            p.error = s.error;
            p.audio = s.audio;
            p.audioDevice = s.audioDevice;
            p.audioError = s.audioError;
            p.w = s.w;
            p.h = s.h;
            if (s.title) p.title = decodeTitle(s.title);
            /* s.id: the player has found the video, and with it the track. A status from before this play says another's */
            if (s.id && !this.subs && this.data.settings.subtitles && (!this.current.id || s.id === this.current.id)) this._loadSubs(s.id);
            this._followSubs();
            const key = `${p.state}|${Math.floor(p.pos)}|${p.dur}|${p.error}|${p.title}|${p.audio}|${p.audioDevice}|${p.audioError}|${p.online}|${Math.ceil(p.wait)}|${p.subs}|${p.subLine}|${p.w}x${p.h}`;
            if (s.id && !this.current.id) {
                /* a link typed in: now it is known what it was */
                this.current.id = s.id;
                this.data.remember({ id: s.id, title: p.title, duration: p.dur });
                this.m.history = this.data.history;
            }
            if (this.current.id && s.pos - this.savedAt >= SAVE_POSITION_S) {
                this.savedAt = s.pos;
                this.data.savePosition(this.current.id, s.pos, p.dur);
            }
            if (key !== shownBefore) this.drawn.render();
        });
    }

    /* ---- subtitles: the player fetches a video's lines the first time they are wanted, and they are shown here by where it says it is ---- */

    _loadSubs(id) {
        const subs = this.subs = { state: 'loading', cues: [] };
        return this.player.slow(`subs ${id}`).then((a) => {
            if (this.subs !== subs) return;
            if (a.unreachable) {
                this.subs = null;       // the player is away: asked again when a status says it is back
                return;
            }
            if (a.ok) {
                subs.cues = a.cues || [];
                subs.state = subs.cues.length ? 'on' : 'none';
                this.log.info(`subtitles: ${subs.cues.length} lines${a.lang ? ` in ${a.lang}` : ''}`);
            } else {
                subs.state = 'failed';
                this.log.warn(`subtitles: ${a.error}`);
            }
            this._followSubs();
            this.drawn.render();
        });
    }

    /* What the button says, and the line for where the picture is. */
    _followSubs() {
        const p = this.m.player;
        if (!p) return;
        const on = this.data.settings.subtitles, subs = this.subs;
        p.subs = !on ? 'off' : subs ? subs.state : 'loading';
        p.subLine = on && subs ? cueAt(subs.cues, (p.pos + (p.state === 'playing' ? SUB_LEAD_S : 0)) * 1000) : '';
    }

    /* One button, on the player, and kept in the settings. Off and on again tries again, if they failed. */
    _toggleSubs() {
        const on = !this.data.settings.subtitles;
        this.data.setSubtitles(on);
        this.m.settings = this.data.settings;
        this.log.info(`subtitles ${on ? 'on' : 'off'}`);
        if (on && this.subs && this.subs.state === 'failed') this.subs = null;
        this._followSubs();
        this.drawn.render();
    }

    _rememberPosition() {
        const p = this.m.player;
        if (p && this.current && this.current.id) this.data.savePosition(this.current.id, p.pos, p.dur);
    }

    _pageClosed(page) {
        if (page === 'player') this._leftPlayer();
        else if (page === 'signin') this._signInStop();
        this._fetchThumbs();    // whichever page this was, it may have uncovered a list
    }

    /* The HMI's BACK, or the app's: playback stops with the page, and the frame file stays for the next play. */
    _leftPlayer() {
        clearInterval(this.poll);
        clearInterval(this.ticker);
        this.poll = null;
        this.ticker = null;
        this._rememberPosition();
        this.current = null;
        this.subs = null;
        this.m.player = null;
        this.m.history = this.data.history;
        /* Home starts with what is unfinished, and this may be that now */
        const home = this.m.feeds.home;
        if (home && home.rows) this.m.feeds.home = Object.assign({}, home, { rows: this._homeRows(home.rows.filter((r) => !r.left)) });
        this.player.cmd('stop');
        this.drawn.render();
    }

    _playPause() {
        const p = this.m.player;
        if (!p) return undefined;
        this.stateSeq++;
        if (!this._showing()) {
            /* A tap's 300 ms can run out behind the camera, and the HMI may send the dial's push here too: the log says. Nothing starts out
             * of sight, so a press only says what happens when it shows again. On a video the app paused, all the driver knows is that it
             * played, so the press is a pause and stays one. On their own pause it is a play, and that goes on then. */
            this.log.info(`a press while the video does not show, in state ${p.state}`);
            const auto = this.autoPaused;
            this.autoPaused = !auto;
            this.driverPaused = auto;
            return this.player.cmd('pause');
        }
        this.autoPaused = false;
        this.driverPaused = false;
        if (p.state === 'paused') {
            p.state = 'playing';
            this.drawn.render();
            return this.player.cmd('resume');
        }
        if (p.state === 'ended') {
            p.state = 'buffering';
            p.pos = 0;
            this._stage('buffering');
            this.drawn.render();
            return this.player.cmd('resume');
        }
        if (p.state === 'error') return this._retry();
        this.driverPaused = true;
        p.state = 'paused';
        this.drawn.render();
        return this.player.cmd('pause');
    }

    /* The same video from the same place, whatever became of the last try: the player drops its resolver and its ffmpeg. */
    _retry() {
        const p = this.m.player;
        if (!p || !this.current) return undefined;
        this.autoPaused = false;
        this.driverPaused = false;
        this._startOver('resolving');
        this.drawn.render();
        return this._play(p.pos);
    }

    _seekBy(by) {
        const p = this.m.player;
        if (!p || p.live) return undefined;
        return this._seekTo(Math.max(0, p.pos + by));
    }

    _seekTo(at) {
        const p = this.m.player;
        if (!p || p.live) return undefined;
        p.pos = p.dur > 0 ? Math.min(at, Math.max(0, p.dur - 1)) : at;
        this.drawn.render();
        const said = this.player.cmd(`seek ${p.pos.toFixed(1)}`);
        this._holdIfHidden();       // a seek starts an ended video: the dial is read whatever shows
        return said;
    }

    /* What the car shows changed: a player that shows nothing pauses, and goes on when it shows again. */
    _showChanged() {
        this._fetchThumbs();
        const p = this.m.player;
        if (!p) return;
        const visible = this._showing();
        if (!visible && !this.autoPaused && (p.state === 'playing' || p.state === 'resolving' || p.state === 'buffering' || p.state === 'stalled')) {
            /* The pause is said even if the driver paused first: that press may never have reached the player, and nothing may play
             * behind the camera. Only a pause of this file's own is taken back when the video shows again. */
            this.autoPaused = !this.driverPaused;
            this.stateSeq++;
            /* p.state is said here too, not left to the next status: another interrupt can come before that. Only a video that plays
             * changes: before its first frame the player holds the pause for that frame and goes on starting, and the page says so. */
            if (p.state === 'playing') p.state = 'paused';
            this.player.cmd('pause');
            this._rememberPosition();
        } else if (visible && this.autoPaused) {
            this.autoPaused = false;
            if (p.state === 'ended') return;    // nothing to go on with: to the player at the end, a resume means from 0
            this.stateSeq++;
            if (p.state === 'paused') p.state = 'playing';
            this.player.cmd('resume');
        }
    }

    /* ---- signing in: the player tool talks to Google, and the driver approves on their phone ---- */

    _signInPage() {
        this.m.signin = { step: this.m.configured ? 'offer' : 'nosetup' };
        this.drawn.push('signin');
    }

    _signInStart() {
        const seq = ++this.signinSeq;
        clearTimeout(this.signinTimer);
        this.m.signin = { step: 'waiting' };
        this.drawn.render();
        return this.player.slow('signin-start').then((a) => {
            if (seq !== this.signinSeq || !this.m.signin) return;
            if (!a.ok) {
                this.m.signin = { step: a.reason === 'nosetup' ? 'nosetup' : 'error', why: a.error };
                this.drawn.render();
                return;
            }
            this.signinEnds = Date.now() + (a.expires_in || 1800) * 1000;
            this.m.signin = { step: 'code', code: a.code, url: a.url, minutes: Math.ceil((a.expires_in || 1800) / 60) };
            this.drawn.render();
            this._signInWait(seq, (a.interval || SIGNIN_POLL_MS / 1000) * 1000);
        });
    }

    _signInWait(seq, ms) {
        this.signinTimer = setTimeout(() => this._signInPoll(seq, ms), ms);
    }

    _signInPoll(seq, ms) {
        return this.player.slow('signin-poll').then((a) => {
            if (seq !== this.signinSeq || !this.m.signin) return;
            if (a.ok && a.status === 'done') {
                this.m.account = { name: a.name };
                this.m.feeds = {};
                this.m.signin = { step: 'done', name: a.name };
                this._showTab('home');      // BACK from here finds Home as well
                return;
            }
            if (a.ok && (a.status === 'denied' || a.status === 'expired')) {
                this.m.signin = { step: a.status };
                this.drawn.render();
                return;
            }
            /* still waiting; or the connection dropped for a moment, and the code is still good */
            const minutes = Math.max(1, Math.ceil((this.signinEnds - Date.now()) / 60000));
            if (this.m.signin.minutes !== minutes) {
                this.m.signin.minutes = minutes;
                this.drawn.render();
            }
            this._signInWait(seq, a.interval ? a.interval * 1000 : ms);
        });
    }

    _signInStop() {
        this.signinSeq++;
        clearTimeout(this.signinTimer);
        this.m.signin = null;
    }

    /* Over browse, or over Settings when it began there. */
    _signInHome() {
        while (this.drawn.top() !== 'browse') this.drawn.pop();
        this._showTab('home');
    }

    _signOut() {
        return this.player.slow('signout').then(() => {
            this._signedOutNow();
        });
    }

    /* ---- settings ---- */

    _setQuality(q) {
        this.data.setQuality(q);
        this.m.settings = this.data.settings;
        this.drawn.render();
        return this.player.cmd(`quality ${q}`);
    }

    _askServer() {
        return this._spell('Server address').then((text) => {
            if (text === null) return undefined;
            const url = String(text).trim();
            if (url && !/^https:\/\/\S+$/.test(url)) {
                this.m.settingsNote = 'A server address starts with https://';
                this.drawn.render();
                return undefined;
            }
            this.data.setInstance(url);
            this.m.settings = this.data.settings;
            this.m.settingsNote = '';
            this.drawn.render();
            return this.player.cmd(`instance ${url || '-'}`);
        });
    }

    _clearHistory() {
        this.data.clearHistory();
        this.m.history = this.data.history;
        this.drawn.render();
    }

    /* ---- Send logs online: off until pressed, and off again by itself after a day. The player does the sending. The app is off the
     * network, so it hands the player its log a piece at a time. ---- */

    _toggleLogs() {
        if (this.data.logsLeft(Date.now())) return this._logsOff('');
        this.data.startLogs(Date.now());
        this.m.settingsNote = '';
        return this._tellLogs(true);
    }

    /* The player knows nothing of this when it starts, and it is the one that ends it if this app is not there to. */
    _tellLogs(pressed) {
        const left = this.data.logsLeft(Date.now());
        if (!left) {
            this._logsStopped();
            return this.player.cmd('logs off');
        }
        const was = !!this.logsTimer;
        return this.player.cmd(`logs on ${this.data.settings.logsId} ${left}`).then((a) => {
            /* a player going down again as it came back: it stays on, and the next 'connected' says so. A crash is when the logs matter */
            if (a.unreachable && !pressed) return;
            if (!a.ok) {
                this._logsStopped();
                this.data.stopLogs();
                this.m.settingsNote = a.unreachable ? a.error : a.error === 'unknown command' ? 'To send logs, update the YouTube player tool in the Store' : a.error;
                this.drawn.render();
                return;
            }
            if (!was) this.log.info('logs: sending online');
            if (!this.logsTimer) this.logsTimer = setInterval(() => this._logsTick(), LOGS_TICK_MS);
            this._showLogs(a);
            this._handOverLog();
        });
    }

    _logsTick() {
        if (!this.data.logsLeft(Date.now())) {
            this._logsOff('the time is up');
            return;
        }
        this._handOverLog();
        if (this.drawn.top() === 'settings') this._askLogs();
    }

    _logsOff(why) {
        this.data.stopLogs();
        this._logsStopped();
        this.log.info(`logs: off${why ? `, ${why}` : ''}`);
        this.drawn.render();
        return this.player.cmd('logs off');
    }

    _logsStopped() {
        clearInterval(this.logsTimer);
        this.logsTimer = null;
        this.m.logs = null;
    }

    /* How it is going, for the row in Settings. */
    _askLogs() {
        if (!this.logsTimer) return undefined;
        return this.player.cmd('logs').then((a) => {
            if (a.ok && a.logs === 'on' && this.logsTimer) this._showLogs(a);
        });
    }

    _showLogs(a) {
        const was = JSON.stringify(this.m.logs);
        this.m.logs = { hours: Math.ceil(this.data.logsLeft(Date.now()) / 3600), id: this.data.settings.logsId, sent: a.sent || 0, note: a.note || '' };
        if (JSON.stringify(this.m.logs) !== was) this.drawn.render();
    }

    /* A piece of the log. Only once the player has all of it does it count as handed over: a line may go twice, none may be lost. */
    _handOverLog() {
        if (this.logsHanding || !this.appLog) return undefined;
        const piece = this.appLog.unsent();
        if (!piece) return undefined;
        this.logsHanding = true;
        return Promise.all(piece.lines.map((l) => this.player.cmd(`logline ${l}`))).then((answers) => {
            this.logsHanding = false;
            if (answers.every((a) => a.ok)) this.appLog.markSent(piece.place);
        });
    }
}

function fmtLeft(s) {
    const t = Math.max(0, Math.floor(s));
    const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = String(t % 60).padStart(2, '0');
    return h ? `${h}:${String(m).padStart(2, '0')}:${sec}` : `${m}:${sec}`;
}

/* The words showing at ms, of [start ms, end ms, words] in order and none overlapping, or ''. */
function cueAt(cues, ms) {
    let lo = 0, hi = cues.length - 1;
    while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        if (cues[mid][0] > ms) hi = mid - 1;
        else if (cues[mid][1] <= ms) lo = mid + 1;
        else return cues[mid][2];
    }
    return '';
}

/* The player hands titles over as JSON string content. */
function decodeTitle(s) {
    try {
        return JSON.parse(`"${s}"`);
    } catch (e) {
        return s;
    }
}

module.exports = { Controller, decodeTitle };
