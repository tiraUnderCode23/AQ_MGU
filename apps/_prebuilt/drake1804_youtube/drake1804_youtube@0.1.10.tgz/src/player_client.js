'use strict';
/**
 * The app's side of the player's control socket (native/ytplay/README.md). Each command gets one JSON line. Two
 * connections: one for play, pause, seek and status, which must answer at once, and one for search and thumb, which wait
 * for the resolver and would hold up whatever is behind them on the same connection.
 *
 *   cmd(line) -> Promise of the answer, { ok: false, error } when the player cannot be reached
 *   slow(line) -> the same, on the other connection
 *   on 'connected': the player is there (again): say what it should know
 */
const EventEmitter = require('events');
const net = require('net');

const RECONNECT_MS = 2000;
const ANSWER_MS = 45000;
const UNREACHABLE = 'The YouTube player tool is not running: install it in the Store';

class Line {
    constructor(path, onUp) {
        this.path = path;
        this.onUp = onUp;
        this.sock = null;
        this.up = false;
        this.closed = false;
        this.buf = '';
        this.waiting = [];
        this.retry = null;
    }
    connect() {
        if (this.closed || this.sock) return;
        const s = net.connect(this.path);
        this.sock = s;
        s.setEncoding('utf8');
        s.on('connect', () => {
            this.up = true;
            if (this.onUp) this.onUp();
        });
        s.on('data', (d) => this._data(d));
        s.on('error', () => { /* 'close' follows */ });
        s.on('close', () => this._down());
    }
    _down() {
        this.sock = null;
        this.up = false;
        this.buf = '';
        const waiting = this.waiting;
        this.waiting = [];
        waiting.forEach((w) => this._answer(w, { ok: false, error: UNREACHABLE, unreachable: true }));
        if (!this.closed && !this.retry) {
            this.retry = setTimeout(() => {
                this.retry = null;
                this.connect();
            }, RECONNECT_MS);
        }
    }
    _answer(w, a) {
        clearTimeout(w.timer);
        w.resolve(a);
    }
    _data(d) {
        this.buf += d;
        let i;
        while ((i = this.buf.indexOf('\n')) >= 0) {
            const line = this.buf.slice(0, i);
            this.buf = this.buf.slice(i + 1);
            const w = this.waiting.shift();
            if (!w) continue;
            let a;
            try {
                a = JSON.parse(line);
            } catch (e) {
                a = { ok: false, error: 'The player gave a bad answer' };
            }
            this._answer(w, a);
        }
    }
    send(line) {
        return new Promise((resolve) => {
            if (!this.up) {
                resolve({ ok: false, error: UNREACHABLE, unreachable: true });
                return;
            }
            const w = { resolve, timer: null };
            /* a player that stays silent: this connection is no use any more */
            w.timer = setTimeout(() => {
                if (this.sock) this.sock.destroy();
            }, ANSWER_MS);
            this.waiting.push(w);
            this.sock.write(`${line}\n`);
        });
    }
    close() {
        this.closed = true;
        clearTimeout(this.retry);
        if (this.sock) this.sock.destroy();
    }
}

class PlayerClient extends EventEmitter {
    constructor(path) {
        super();
        this.ctl = new Line(path, () => { this.fresh = true; this._bothUp(); });
        this.other = new Line(path, () => this._bothUp());
        this.fresh = false;
    }
    /* 'connected' is about the command line coming up, but what it sets off uses both. The other line alone coming back,
     * after a search that hung, says nothing: the player has not gone anywhere. */
    _bothUp() {
        if (!this.fresh || !this.ctl.up || !this.other.up) return;
        this.fresh = false;
        this.emit('connected');
    }
    connect() {
        this.ctl.connect();
        this.other.connect();
    }
    cmd(line) { return this.ctl.send(line); }
    slow(line) { return this.other.send(line); }
    close() {
        this.ctl.close();
        this.other.close();
    }
}

module.exports = { PlayerClient, UNREACHABLE };
