/**
 * The YouTube app: the oap-sdk's side. An OAP app runs under MainApp's CPU limit and its crash ladder, so this draws the
 * screens and sends commands; the drake1804-ytplay tool fetches and decodes. See ../README.md.
 *
 * The HMI side is small: an entry state and two over it (tools/gen_rhmi.js), all under the renderer's layer, whose
 * focusable buttons are the proxies of what the drawn page can press. The HMI's BACK closes the state on top.
 */
'use strict';
const path = require('path');
const OnlineApp = require('oap-sdk/src/core/OnlineApp.js');
const logging = require('oap-sdk/src/logging/logging');
const someipBuilders = require('oap-sdk/src/someip/someipBuilders');
const kit = require('./kit_record.js');
const { spell } = require('./speller.js');
const { AppData, AppLog, describe } = require('./appdata.js');
const { Controller } = require('./controller.js');
const { Drawn } = require('./drawn.js');
const { PlayerClient } = require('./player_client.js');

const APP_ID = 'drake1804_youtube';
const SOCKET = process.env.YTPLAY_SOCKET || '/run/drake1804-ytplay/ctl.sock';
const DATA_DIR = path.join(__dirname, '..', '..', 'data');

/* Where the sdk's logger goes is the journal, which may not outlive a restart of the unit: everything goes to a file as well. */
const sdkLogger = logging.getSDKLogger();
const appLog = new AppLog(DATA_DIR);
const logger = Object.create(sdkLogger);
['info', 'warn', 'error'].forEach((level) => {
    logger[level] = (...args) => {
        sdkLogger[level](...args);
        appLog.line(level, args.join(' '));
    };
});
/* Written down, and then it goes on to crash as it would have. */
process.on('uncaughtException', (err) => {
    appLog.line('crash', err && err.stack ? err.stack : err);
    throw err;
});
process.on('unhandledRejection', (err) => appLog.line('rejected', err && err.stack ? err.stack : err));
const IF_FRONTCCU = 'de.bmw.infotainment.controlelements.FrontCCU';
const PROXIES = [32, 26, 12];
const hostName = (depth) => `ST_OnlineApps_YT${depth}`;
const proxyName = (depth, i) => `yt${depth}P${i}`;
const NOTICE = 'ytNotice';
const PRESS_DEDUPE_MS = 400;
const HIDE_SETTLE_MS = 800;
const ROW_KEY = 2;                  // a press's row in a raw userEvent's parameterMap
const VALUE_KEY = 0;                // a focus event's value
const FOREGROUND_REASONS = ['ENTRY_POINT', 'LUM', 'BOOKMARK', 'START_WIDGET', 'TRIGGER_HMI', 'SPEECH_COMMAND'];

/* RHMI event values arrive as booleans, or as 1/0 on some HMIs. */
function isTrue(raw) {
    return raw === true || raw === 'true' || raw === 1 || raw === '1';
}

class YouTube extends OnlineApp {
    constructor() {
        super();
        this._states = {};
        this._components = {};
        this._actionById = {};
        this._focusById = {};
        this._lastPress = {};
        this._written = {};
        this._visibleStates = new Set();
        this._visible = false;
        this._sawForeground = false;
        this._hideTimer = null;
        this._shutdownPromise = null;
        this._drawn = new Drawn({
            log: logger,
            appId: APP_ID,
            model: () => this._controller.model(),
            act: (act) => this._controller.act(act),
            openState: (name) => this._openState(name),
            closeState: (name) => this._closeState(name),
            setText: (name, text) => this._setText(name, text),
            show: (name, on) => this._show(name, on),
            hostName,
            proxyName,
            proxies: PROXIES
        });
        this._controller = new Controller({
            log: logger,
            player: new PlayerClient(SOCKET),
            data: new AppData(DATA_DIR),
            appLog,
            drawn: this._drawn,
            spell: (title) => spell(this, title),
            makeImage: kit.makeImage,
            dropImage: (img) => {
                this._drawn.gpu.dropImage(img);
                kit.dropImage(img);
            }
        });
        this._drawn.on('unavailable', (why) => {
            logger.warn(`renderer: ${why}`);
            this._setText(NOTICE, why);
        });
        this.on('initialized', () => {
            this._appInitialized().catch((err) => logger.error(`init failed: ${err && err.message}`));
        });
        this.on('shutdown', (reason) => this._handleShutdown(reason));
        this.on('error', (err) => logger.warn(`OnlineApp error: ${err && err.message}`));
        this.on('entryPointExecute', (uuid) => this._onEntryPointExecute(uuid));
        this.on('changeVisibility', (data) => {
            if (data && data.visible === false) this._leftScreen();
        });
    }

    /* The whole app, not one of its states on the way to another. */
    _leftScreen() {
        this._visibleStates.clear();
        this._setVisible(false);
        this._drawn.leftScreen();
    }

    _appInitialized() {
        logger.info(`${this.getAppId()} starting`);
        if (!this.rhmiApplication) {
            logger.info('no RhmiApplication for this start reason; initializing without a screen');
            return this.initialized();
        }
        const foreground = this._startedForeground();
        this._controller.start();
        return this._setupRhmi()
            .then(() => this._setupController())
            .then(() => this._drawn.connect())
            .then(() => this._registerEntryPoints())
            .then(() => {
                if (foreground) this.registerActive();
                return this.initialized();
            })
            .then(() => {
                if (foreground) {
                    this._sawForeground = true;
                    this._setVisible(true);
                }
                const last = this.getLastExecutedEntryPointUuid && this.getLastExecutedEntryPointUuid();
                return last ? this._onEntryPointExecute(last) : undefined;
            });
    }

    _startedForeground() {
        const data = this.getVisibilityData && this.getVisibilityData();
        const reason = (data && data.reason) || this.startReason;
        return FOREGROUND_REASONS.includes(reason);
    }

    /* The dial on the player page. Without it the page takes touch only. */
    _setupController() {
        let proxy;
        someipBuilders.buildTypedProxy(IF_FRONTCCU, '1')
            .then((p) => { proxy = p; return proxy.init(); })
            .then(() => proxy.waitUntilAvailable())
            .then(() => proxy.statusRotaryEncoderState.subscribe((s) => this._drawn.frontCcu(s)))
            .then(() => proxy.statusRotaryEncoderState.getValue())
            .then((s) => this._drawn.frontCcu(s))       // where the counter is now, or the first turn only sets that
            .then(() => logger.info('FrontCCU controller subscribed'))
            .catch((err) => logger.warn(`FrontCCU controller unavailable: ${err && err.message}`));
    }

    _setupRhmi() {
        const rhmi = this.rhmiApplication;
        const names = PROXIES.map((n, d) => hostName(d + 1));
        for (const name of names) {
            this._states[name] = rhmi.getByName(name);
            if (!this._states[name]) return Promise.reject(new Error(`uiDescription has no ${name}`));
        }
        this._components[NOTICE] = rhmi.getByName(NOTICE);
        PROXIES.forEach((count, d) => {
            const depth = d + 1;
            for (let i = 0; i < count; i++) {
                const name = proxyName(depth, i);
                this._components[name] = rhmi.getByName(name);
                this._bind(name, () => this._drawn.proxyPress(depth, i));
                this._bindFocus(name, (value) => this._drawn.proxyFocus(depth, i, value));
            }
            const state = this._states[hostName(depth)];
            state.on('focus', (ev) => this._drawn.hostFocus(depth, isTrue(ev && ev.focus)));
            state.on('visible', (ev) => this._stateVisible(hostName(depth), depth, isTrue(ev && ev.visible)));
        });
        // Presses also arrive as the application's raw 'userEvent'; both paths land in _press, which keeps a press
        // delivered twice to one.
        rhmi.on('userEvent', (ev) => {
            const entry = ev && ev.eventType === 'ACTION' && this._actionById[Number(ev.sourceId)];
            if (entry) this._press(entry.name, entry.handler, Number((ev.parameterMap || {})[ROW_KEY]) || 0);
            const focus = ev && ev.eventType === 'FOCUS' && this._focusById[Number(ev.sourceId)];
            if (focus) focus(isTrue((ev.parameterMap || {})[VALUE_KEY]));
        });
        rhmi.on('applicationStackChanged', (stack) => {
            const keys = stack && typeof stack === 'object' ? Object.keys(stack) : [];
            if (!keys.length) return;
            if (Object.prototype.hasOwnProperty.call(stack, 'ROOT_APP')) {
                this._sawForeground = true;
                this._setVisible(true);
            } else if (this._sawForeground) {
                this._leftScreen();
            }
        });
        rhmi.on('restoreHmi', () => {
            logger.info('RESTORE_HMI: writing the proxies again');
            this._written = {};
            this._drawn.render(true);
        });
        return Promise.all(names.map((name) => this._states[name].updateResources()));
    }

    /* The app counts as visible while any of its states is: moving between them hides one before showing the next, so a
     * hide takes effect only if nothing became visible meanwhile. */
    _stateVisible(name, depth, visible) {
        this._drawn.hostVisible(depth, visible);
        if (visible) {
            this._visibleStates.add(name);
            this._sawForeground = true;
            this._setVisible(true);
        } else {
            this._visibleStates.delete(name);
            clearTimeout(this._hideTimer);
            this._hideTimer = setTimeout(() => {
                if (this._visibleStates.size === 0) this._setVisible(false);
            }, HIDE_SETTLE_MS);
        }
    }

    _setVisible(visible) {
        if (this._shutdownPromise || this._visible === visible) return;
        this._visible = visible;
        clearTimeout(this._hideTimer);
        logger.info(`screen ${visible ? 'visible' : 'hidden'}`);
        if (visible) this._written = {};
        if (!this._initialized || !this._appStatusService) return;
        const reports = visible ? [this.registerActive(), this.registerHmiVisible()] :
            [this.unregisterHmiVisible(), this.registerInactive()];
        reports.forEach((report) => Promise.resolve(report).catch((err) =>
            logger.warn(`app status report failed: ${err && err.message}`)));
    }

    _openState(name) {
        if (this._shutdownPromise) return;
        Promise.resolve(this.rhmiApplication.openState(name))
            .catch((err) => logger.warn(`openState ${name} failed: ${err && err.message}`));
    }

    _closeState(name) {
        Promise.resolve(this.rhmiApplication.closeState(name))
            .catch((err) => logger.warn(`closeState ${name} failed: ${err && err.message}`));
    }

    _bind(name, handler) {
        const comp = this._components[name];
        if (!comp) return;
        try {
            this._actionById[Number(comp.getId())] = { name, handler };
        } catch (e) {
            /* no id: the component's own events only */
        }
        comp.on('action', (ev) => this._press(name, handler, Number(ev && ev.row) || 0));
    }

    _bindFocus(name, handler) {
        const comp = this._components[name];
        if (!comp) return;
        try {
            this._focusById[Number(comp.getId())] = handler;
        } catch (e) {
            /* no id: the component's own events only */
        }
        comp.on('focus', (ev) => handler(isTrue(ev && ev.value)));
    }

    _press(name, handler, row) {
        const now = Date.now();
        const key = `${name}.${row}`;
        if (now - (this._lastPress[key] || 0) < PRESS_DEDUPE_MS) return;
        this._lastPress[key] = now;
        handler();
    }

    /* Writes a cell only when its value changed: each write is a call to the HMI. */
    _setText(name, text) {
        const comp = this._components[name];
        const key = `${name}.text`;
        if (!comp || this._written[key] === text) return;
        this._written[key] = text;
        Promise.resolve(comp.setValue(0, 'Text', text, 'Text'))
            .catch((err) => logger.warn(`text ${name} failed: ${err && err.message}`));
    }

    _show(name, visible) {
        const comp = this._components[name];
        const key = `${name}.visible`;
        if (!comp || this._written[key] === visible) return;
        this._written[key] = visible;
        Promise.resolve(comp.setProperty('Visible', visible ? 1 : 0, 'UInt'))
            .catch((err) => logger.warn(`visibility ${name} failed: ${err && err.message}`));
    }

    /* The manager inserts the public tile from application.json and hands it over at start; a tap comes as
     * 'entryPointExecute'. */
    _registerEntryPoints() {
        const descriptions = (this.appDescription && this.appDescription.application.entryPoints) || [];
        const ours = this.getEntryPoints().find((ep) => descriptions.some((d) => d.uuid === ep.getDescription().uuid));
        if (!ours) return Promise.reject(new Error('no entry point handed over by the manager'));
        const description = ours.getDescription();
        return ours.init()
            .then(() => this.rhmiApplication.mapEntryState(description.uuid, this._states[hostName(1)]))
            .then(() => Promise.resolve()
                .then(() => ours.entryPoint.setText(description.textId))
                .then(() => (description.icon ? ours.entryPoint.setIcon(description.icon) : undefined))
                .catch((err) => logger.warn(`entry point text/icon: ${err && err.message}`)))
            .then(() => ours.setAvailability('ENABLED'))
            .then(() => logger.info(`entry point ${description.name} ENABLED`));
    }

    _onEntryPointExecute(uuid) {
        if (this._shutdownPromise || !this.rhmiApplication || !uuid) return Promise.resolve();
        this._sawForeground = true;
        this._setVisible(true);
        return Promise.resolve(this.rhmiApplication.openEntryState(uuid))
            .catch((err) => logger.warn(`openEntryState failed: ${err && err.message}`));
    }

    _handleShutdown(reason) {
        if (this._shutdownPromise) return this._shutdownPromise;
        logger.info(`shutting down (${describe(reason)})`);
        clearTimeout(this._hideTimer);
        this._controller.stop();
        this._controller.player.cmd('stop');
        this._controller.player.close();
        this._drawn.close();
        this._shutdownPromise = Promise.resolve()
            .then(() => this.destroyBundles().catch((err) => logger.info(`destroyBundles: ${err && err.message}`)))
            .then(() => process.exit(0));
        return this._shutdownPromise;
    }
}

const app = new YouTube();
app.start().catch((err) => {
    /* Stays resident so the manager can stop or restart it. */
    logger.error(`failed to start: ${err && err.message}`);
});
