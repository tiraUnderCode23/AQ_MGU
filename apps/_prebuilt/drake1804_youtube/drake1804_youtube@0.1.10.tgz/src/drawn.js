'use strict';
/**
 * The screens on the renderer: the connection, the placement (its own layer over the host state, on the app area), the page stack, the
 * HMI host states and their proxies, touch and the dial. src/ui.js makes each frame, on the logical 1790 x 638 of iDrive 7's app area;
 * another size of box gets that fitted in.
 *
 * The player's layer goes over iDrive's top bar as well, to the screen's right edge, on a logical FULL. A renderer that answers that placement
 * with an error, or by going away, leaves the player on the app area until the app restarts.
 *
 * Pages: browse is the entry state; each page over it is the next host state, so the HMI's BACK closes it. A host state's
 * proxies are its focusable buttons, one per item of the drawn page that has one, in focus order: the HMI's focus on one
 * draws the focus ring there, a press on one presses the item. Touch in the claimed area hits the items themselves.
 *
 * The dial: with the renderer's controller gate it comes here and moves the focus. Without it the HMI moves the focus
 * over the proxies itself. On the player either way the dial seeks: there FrontCCU is read as well, and the page has one
 * proxy, so the HMI's focus stays on Play.
 *
 * Touch on the player: a tap on the picture is Play/Pause, once it is clear no second tap is coming. A second tap seeks 10 s, back on the
 * layer's left half and forward on its right, and so does each tap right after it. The controls show while the video is not simply playing,
 * and for CONTROLS_MS once it starts to, seeks, or one of them is pressed.
 *
 * Between states: the HMI's BACK takes the focus from a state and hides it, and only then shows the one under it. Taking the layer off for that
 * would show the plain state and its proxies for as long as the HMI takes, so the layer stays up for BETWEEN_STATES_MS. A popup starts the same
 * way, so it waits as well. HOME and BACK from the first page are told apart by leftScreen(), and don't.
 *
 * Emits 'shown' (on), when the layer goes on or off; 'page-closed' (page), when the HMI's BACK or the app closed a page; 'unavailable'
 * (why) and 'available' as the renderer comes and goes.
 */
const EventEmitter = require('events');
const { RenderClient, videoOp } = require('./mgu_render_client.js');
const kit = require('./kit_record.js');
const { frame, hit, W, H, CARD_STEP, CARD_Y, FULL } = require('./ui.js');

const DEPTHS = 3;
const FPS = 30;
const KEEPALIVE_MS = 1000;              // the renderer hides an app silent for 3 s
const CLOSED_RESHOW_MS = 700;           // a touch outside that left the page where it was
const BETWEEN_STATES_MS = 500;          // how long the HMI gets to arrive at another state. A guess: each stay is logged, so a car's logs can say
const DRAG_PX = 14;
const VIDEO_ID = 1;
const FRAME_FILE = '/dev/shm/mgu-video-yt';
const SEEK_PER_DETENT_S = 10;
const SEEK_SETTLE_MS = 300;             // detents in a row make one seek
const APP_AREA = { w: W, h: H };
const DOUBLE_TAP_MS = 300;              // a tap on the picture waits this long for a second one
const TAP_SLOP_PX = 40;                 // a touch that ends further than this from where it began was not a tap
const CONTROLS_MS = 2000;
const JUMP_SHOWN_MS = 600;
const COVER_REFUSED_MS = 1000;          // an error this soon after the placement over the top bar was about that
const DIAL_MAX_STEP = 24;               // a bigger jump of the counter is a stale or garbage sample
// FrontCCU frontRotaryEncoderPushButton pushed (short, long): by name or ordinal
const PUSHED = ['DREHGEBER_KURZ_GEDRUECKT', 'DREHGEBER_LANG_GEDRUECKT', 1, 2];
const RELEASED = ['KEINE_BETAETIGUNG', 0];
const COUNTER_INVALID = 0xffff;

class Drawn extends EventEmitter {
    /**
     * host: { log, appId, model(), act(act), openState(name), closeState(name), hostName(depth), proxyName(depth, i),
     * setText(name, text), show(name, on), proxies (count per depth) }.
     */
    constructor(host, opts) {
        super();
        this.host = host;
        this.log = host.log;
        this.gpu = (opts && opts.client) || new RenderClient(host.appId, this.log, { kit, mode: 'layer' });
        this.gpu.fps(FPS);
        this.rec = new kit.Recorder(W, H);
        this.available = false;
        this.stack = [{ page: 'browse' }];
        this.focus = 0;
        this.scroll = { list: 0, max: 0 };
        this.firstCard = 0;
        this.items = [];
        this.visibleHosts = new Set();
        this.focusLost = false;         // the top host state lost the HMI's focus: a popup
        this.suspended = false;         // the HMI's speller is up
        this.closedHide = false;
        this.between = null;            // the HMI let go of the page: running while it may only be moving to another
        this.lostAt = 0;
        this.appLeft = false;           // the HMI said the whole app left the screen
        this.on_ = false;
        this.dirty = false;
        this.sentAt = 0;
        this.keepalive = null;
        this.touch = null;
        this.screen = null;
        this.appArea = null;
        this.size = APP_AREA;
        this.placed = '';
        this.cover = true;              // the renderer has not refused the player's layer over the top bar
        this.coveredAt = 0;
        this.stateShown = null;
        this.holdControls = false;
        this.controlsTimer = null;
        this.tapOpen = false;
        this.tapTimer = null;
        this.jump = null;
        this.jumpTimer = null;
        this.fccu = null;
        this.ccu = null;
        this.pendingSeek = 0;
        this.seekTimer = null;
        this.controller = false;
        this.gpu.on('ready', (screen, info) => this._ready(screen, info));
        this.gpu.on('close', () => {
            this._coverRefused('the renderer went away');
            this._gone('the renderer went away');
        });
        this.gpu.on('renderer-error', (why) => this._coverRefused(why));
        this.gpu.on('tick', () => { if (this.dirty) this.render(); });
        this.gpu.on('touch', (phase, x, y) => this._touch(phase, x, y));
        this.gpu.on('closed', () => {
            this.closedHide = true;
            this._updateShow();
            setTimeout(() => {
                this.closedHide = false;
                this._updateShow();
            }, CLOSED_RESHOW_MS);
        });
        this.gpu.on('state', (s) => this.emit('on-screen', !!s.onScreen));
        this.gpu.on('ccu', (e) => this._ccu(e));
    }

    connect() { this.gpu.connect(); }

    close() {
        clearInterval(this.keepalive);
        clearTimeout(this.seekTimer);
        clearTimeout(this.between);
        this._forgetTouch();
        this.gpu.removeAllListeners('close');
        this.gpu.close();
    }

    _ready(screen, info) {
        if (!info) return this._gone('This renderer is too old: update Renderer in the Store');
        if (!info.video) return this._gone('This renderer has no video: update Renderer in the Store');
        if (info.modes.indexOf('layer') < 0) return this._gone('The renderer offers no layer');
        this.screen = screen;
        this.appArea = info.appArea;
        this.controller = !!info.controller;
        this.gpu.mode('layer');
        this._place();
        this.available = true;
        this._syncVideo();
        this.emit('available');
        this._updateShow();
        return undefined;
    }

    /* The player over the top bar, to the screen's right edge; every other page on the app area. */
    _place() {
        if (!this.appArea) return;
        const a = this.appArea;
        const cover = this.cover && this.top() === 'player';
        const box = cover ? { x: a.x, y: 0, w: this.screen.w - a.x, h: this.screen.h } : a;
        const size = cover ? FULL : APP_AREA;
        const scale = Math.min(box.w / size.w, box.h / size.h);
        this.gpu.place({ x: box.x, y: box.y, w: box.w, h: box.h, scale, ox: Math.round((box.w - size.w * scale) / 2), oy: Math.round((box.h - size.h * scale) / 2) });
        const placed = `${box.w}x${box.h} at ${box.x},${box.y}`;
        if (placed === this.placed) return;
        this.placed = placed;
        this.size = size;
        this.coveredAt = cover ? Date.now() : 0;
        this.rec = new kit.Recorder(size.w, size.h, { textScale: scale });
        if (this.on_) this.gpu.claim([{ x: 0, y: 0, w: size.w, h: size.h }]);
        this.log.info(`renderer: layer ${placed}, scale ${scale.toFixed(3)}, controller ${this.controller}`);
    }

    _coverRefused(why) {
        if (!this.coveredAt || Date.now() - this.coveredAt > COVER_REFUSED_MS) return;
        this.log.warn(`renderer: the player stays on the app area: ${why}`);
        this.cover = false;
        this.coveredAt = 0;
        this._place();
        this.render();
    }

    _gone(why) {
        this.available = false;
        this._forgetTouch();
        this.items = [];
        this._proxies();                // no drawn page: no blank buttons on the plain one under it
        this._updateShow();
        this.emit('unavailable', why);
    }

    top() { return this.stack[this.stack.length - 1].page; }

    /* The player page names the frame file; no other page holds it. */
    _syncVideo() {
        this.gpu.video(VIDEO_ID, this.top() === 'player' ? FRAME_FILE : null);
    }

    /* A new page on top. A new size sends the renderer its videos again: so one that is going goes first, and a new one comes after. */
    _settle() {
        this._forgetTouch();
        this.stateShown = null;
        if (this.top() !== 'player') this._syncVideo();
        this._place();
        if (this.top() === 'player') this._syncVideo();
        this.render();
    }

    _enter() {
        this.focus = 0;
        this.scroll.list = 0;
        this._settle();
    }

    push(page) {
        const was = this.stack[this.stack.length - 1];
        was.focus = this.focus;
        was.list = this.scroll.list;
        if (this.stack.length >= DEPTHS) {
            this.stack[DEPTHS - 1] = { page };
        } else {
            this.stack.push({ page });
            this.host.openState(this.host.hostName(this.stack.length));
        }
        this._enter();
    }

    /* Another page in the top one's place: BACK goes where it would have gone. */
    replace(page) {
        this.stack[this.stack.length - 1] = { page };
        this._enter();
    }

    /* The app itself closes the page on top. */
    pop() {
        if (this.stack.length < 2) return;
        const depth = this.stack.length;
        const { page } = this.stack.pop();
        this._back();
        this.host.closeState(this.host.hostName(depth));
        this.emit('page-closed', page);
    }

    _back() {
        const now = this.stack[this.stack.length - 1];
        this.focus = now.focus || 0;
        this.scroll.list = now.list || 0;
        this._settle();
    }

    /* The HMI went back under the page on top: its BACK. */
    _closedTo(depth) {
        if (depth >= this.stack.length) return;
        const closed = this.stack.slice(depth).map((s) => s.page);
        this.stack.length = depth;
        this._back();
        closed.reverse().forEach((page) => this.emit('page-closed', page));
    }

    hostVisible(depth, visible) {
        if (visible) {
            this.visibleHosts.add(depth);
            this._closedTo(depth);
            this.focusLost = false;
            this.dirty = true;
        } else {
            this.visibleHosts.delete(depth);
        }
        this._hmiChanged();
    }

    hostFocus(depth, focus) {
        if (focus) this._closedTo(depth);
        if (depth === this.stack.length) this.focusLost = !focus;
        this._hmiChanged();
    }

    /* A state of this app is up, with the HMI's focus. */
    _hmiHolds() {
        return this.visibleHosts.size > 0 && !this.focusLost;
    }

    _hmiChanged() {
        if (this._hmiHolds()) {
            this.appLeft = false;
            this._stopWaiting();
            if (this.lostAt) this.log.info(`hmi: back on a state after ${Date.now() - this.lostAt} ms`);
            this.lostAt = 0;
        } else if (this.on_ && !this.between && !this.appLeft) {
            this.lostAt = Date.now();
            this._forgetTouch();
            this.between = setTimeout(() => {
                this.between = null;
                this._updateShow();
            }, BETWEEN_STATES_MS);
        }
        this._updateShow();
    }

    _stopWaiting() {
        clearTimeout(this.between);
        this.between = null;
    }

    /* HOME, or BACK from the first page: no state is coming to wait for. */
    leftScreen() {
        this.appLeft = true;
        this.lostAt = 0;
        this._stopWaiting();
        this._updateShow();
    }

    proxyFocus(depth, i, value) {
        if (depth === this.stack.length && value) {
            this.focus = this._itemOfProxy(i);
            this.render();
        }
    }

    proxyPress(depth, i) {
        if (depth !== this.stack.length) return;
        const at = this._itemOfProxy(i);
        if (this.items[at]) {
            this.focus = at;
            this.host.act(this.items[at].act);
        }
    }

    /* The item behind proxy i: only items with a proxy count. */
    _itemOfProxy(i) {
        let n = -1;
        for (let k = 0; k < this.items.length; k++) {
            if (this.items[k].proxy !== false && ++n === i) return k;
        }
        return 0;
    }

    /* The HMI's speller covers everything while it is up. */
    suspend(on) {
        this.suspended = on;
        this._updateShow();
    }

    _shouldShow() {
        return this.available && !this.suspended && !this.closedHide && (this._hmiHolds() || this.between !== null);
    }

    _updateShow() {
        const on = this._shouldShow();
        if (!on) this._stopWaiting();
        if (on === this.on_) return;
        this.on_ = on;
        this._forgetTouch();
        this.gpu.claim(on ? [{ x: 0, y: 0, w: this.size.w, h: this.size.h }] : []);
        this.gpu.grab(on && this.controller);
        if (on) this.render(true);
        this.gpu.show(on);
        clearInterval(this.keepalive);
        this.keepalive = on ? setInterval(() => {
            if (Date.now() - this.sentAt >= KEEPALIVE_MS) this.render(true);
        }, KEEPALIVE_MS) : null;
        this.emit('shown', on);
    }

    /* Draws now when the renderer is ready for a frame, else at its next tick; force: now, whatever it said. */
    render(force) {
        if (!this.on_ && !force) return;
        if (!this.available) return;
        if (this.gpu.waiting && !force) {
            this.dirty = true;
            return;
        }
        const m = this.host.model();
        const onPlayer = this.top() === 'player';
        const video = onPlayer ? (x, y, w, h) => videoOp(VIDEO_ID, x, y, w, h, 0) : null;
        const f = frame(m, { rec: this.rec, page: this.top(), focus: this.focus, scroll: this.scroll, videoWords: video, size: this.size,
            controls: onPlayer && this._controlsShow(m.player), jump: this.jump });
        this.items = f.items;
        this._proxies();
        this.gpu.frame(this.rec);
        this.sentAt = Date.now();
        this.dirty = false;
        /* frame() moves the list to follow the focus */
        const first = Math.floor(this.scroll.list);
        if (first !== this.firstCard) {
            this.firstCard = first;
            this.emit('scrolled');
        }
    }

    /* Only what changed goes to the HMI: the host writes a cell only when its value changed. */
    _proxies() {
        const depth = this.stack.length;
        const list = this.items.filter((it) => it.proxy !== false);
        const n = this.host.proxies[depth - 1] || 0;
        for (let i = 0; i < n; i++) {
            const name = this.host.proxyName(depth, i);
            if (list[i]) this.host.setText(name, list[i].label);
            this.host.show(name, !!list[i]);
        }
    }

    /* ---- the player's controls ---- */

    _controlsShow(p) {
        const state = p && p.state;
        if (state === 'playing' && this.stateShown !== 'playing') this._holdControls();
        this.stateShown = state;
        return state !== 'playing' || this.holdControls;
    }

    _holdControls() {
        this.holdControls = true;
        clearTimeout(this.controlsTimer);
        this.controlsTimer = setTimeout(() => {
            this.holdControls = false;
            this.render();
        }, CONTROLS_MS);
    }

    /* ---- touch ---- */

    _forgetTouch() {
        this.touch = null;
        this.tapOpen = false;
        this.holdControls = false;
        this.jump = null;
        clearTimeout(this.tapTimer);
        clearTimeout(this.controlsTimer);
        clearTimeout(this.jumpTimer);
    }

    _tapPicture(it, x) {
        if (!it.seeks) {
            this.host.act(it.act);
            return;
        }
        clearTimeout(this.tapTimer);
        if (this.tapOpen) {
            this.tapTimer = setTimeout(() => { this.tapOpen = false; }, DOUBLE_TAP_MS);
            this._jump(x < this.size.w / 2 ? -1 : 1);
            return;
        }
        this.tapOpen = true;
        this.tapTimer = setTimeout(() => {
            this.tapOpen = false;
            this.host.act(it.act);
        }, DOUBLE_TAP_MS);
    }

    _jump(dir) {
        this.jump = { dir, by: (this.jump && this.jump.dir === dir ? this.jump.by : 0) + SEEK_PER_DETENT_S };
        clearTimeout(this.jumpTimer);
        this.jumpTimer = setTimeout(() => {
            this.jump = null;
            this.render();
        }, JUMP_SHOWN_MS);
        this._seekSteps(dir);
    }

    _touch(phase, x, y) {
        if (this.between) return;       // the page may be on its way out
        if (phase === 'down') {
            this.touch = { x0: x, y0: y, top: this.scroll.list, item: hit(this.items, x, y), drag: false };
            return;
        }
        const t = this.touch;
        if (!t) return;
        if (phase === 'move') {
            if (t.y0 < CARD_Y || this.scroll.max <= 0) return;
            const page = this.top();
            if (page !== 'browse' && page !== 'results') return;
            const dx = x - t.x0;
            if (!t.drag && Math.abs(dx) < DRAG_PX) return;
            t.drag = true;
            this.scroll.list = Math.max(0, Math.min(this.scroll.max, t.top - dx / CARD_STEP));
            this.focus = -1;
            this.render();
            return;
        }
        this.touch = null;
        if (t.drag || t.item < 0) return;
        const it = this.items[t.item];
        if (!it || !(x >= it.x && x < it.x + it.w && y >= it.y - 8 && y < it.y + it.h + 8)) return;
        if (it.surface) {
            if (Math.abs(x - t.x0) <= TAP_SLOP_PX && Math.abs(y - t.y0) <= TAP_SLOP_PX) this._tapPicture(it, x);
            return;
        }
        this.focus = it.proxy === false ? this.focus : t.item;
        if (it.seekBar) {
            this.host.act({ do: 'seekTo', at: Math.max(0, Math.min(1, (x - it.x) / it.w)) * it.act.dur });
        } else {
            this.host.act(it.act);
        }
        if (this.top() === 'player') this._holdControls();
        this.render();
    }

    /* ---- the dial ---- */

    /* A FrontCCU.statusRotaryEncoderState sample: the HMI's own view of the dial. An invalid counter keeps the last. */
    frontCcu(s) {
        const last = this.fccu;
        const op = s && s.frontRotaryEncoderOperation;
        const push = s && s.frontRotaryEncoderPushButton;
        this.fccu = {
            knob: typeof op === 'number' && op !== COUNTER_INVALID ? op : (last ? last.knob : COUNTER_INVALID),
            press: PUSHED.indexOf(push) >= 0 ? true : RELEASED.indexOf(push) >= 0 ? false : !!(last && last.press)
        };
        if (last && !this.controller && this.top() === 'player' && this.on_) {
            this._dial(last.knob, this.fccu.knob, false);
        }
    }

    /* The dial through the renderer's controller gate. */
    _ccu(e) {
        const last = this.ccu;
        this.ccu = e;
        if (last) this._dial(last.knob, e.knob, e.press && e.press !== last.press && e.seq !== last.seq);
    }

    _dial(from, to, pushed) {
        if (!this.on_ || this.between) return;
        const steps = ((to - from + 0x18000) % 0x10000) - 0x8000;
        const moved = to !== COUNTER_INVALID && from !== COUNTER_INVALID && steps !== 0 && Math.abs(steps) <= DIAL_MAX_STEP;
        if (moved) {
            if (this.top() === 'player') {
                this._seekSteps(steps);
            } else {
                this.focus = Math.max(0, Math.min(this.items.length - 1, this.focus + steps));
                this.render();
            }
        }
        if (pushed && this.items[this.focus]) this.host.act(this.items[this.focus].act);
    }

    _seekSteps(steps) {
        this.pendingSeek += steps * SEEK_PER_DETENT_S;
        clearTimeout(this.seekTimer);
        this.seekTimer = setTimeout(() => {
            const by = this.pendingSeek;
            this.pendingSeek = 0;
            if (by) this.host.act({ do: 'seekby', by });
        }, SEEK_SETTLE_MS);
        this._holdControls();
        this.render();
    }
}

module.exports = { Drawn, FRAME_FILE, VIDEO_ID, DEPTHS, BETWEEN_STATES_MS };
