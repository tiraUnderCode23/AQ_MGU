'use strict';
/**
 * What the app keeps in its data folder: settings and watch history, each a JSON file written whole. A file that is
 * missing or does not parse is as good as a fresh start.
 */
const fs = require('fs');
const path = require('path');

const MAX_HISTORY = 50;
const MAX_RECENT = 6;
const QUALITIES = [720, 480, 360];
const LOG_MAX = 256 * 1024;     // then the log moves to .1: two files at most
const NEAR_END_S = 30;          // a video this close to its end starts from the beginning next time
const LOGS_S = 24 * 3600;       // one press of Send logs online
const UNSENT_BYTES = 16 * 1024; // of the log, at a time, for the player
const DESCRIBE_MAX = 500;       // of a value, in a log line
const HEAD_BYTES = 64;          // of the log's start, to tell it from another: Linux soon gives a deleted file's inode to a new one

class AppData {
    constructor(dir) {
        this.dir = dir;
        this.settings = Object.assign({ quality: 720, instance: '', subtitles: false, logsUntil: 0, logsId: '' }, this._read('settings.json', {}));
        if (QUALITIES.indexOf(this.settings.quality) < 0) this.settings.quality = 720;
        this.settings.subtitles = this.settings.subtitles === true;
        if (typeof this.settings.instance !== 'string') this.settings.instance = '';
        if (typeof this.settings.logsUntil !== 'number') this.settings.logsUntil = 0;
        if (!/^[0-9a-f]{8}$/.test(this.settings.logsId)) this.settings.logsId = '';
        const history = this._read('history.json', []);
        this.history = Array.isArray(history) ? history.filter((h) => h && typeof h.id === 'string').slice(0, MAX_HISTORY) : [];
        const recent = this._read('recent.json', []);
        this.recent = Array.isArray(recent) ? recent.filter((r) => typeof r === 'string').slice(0, MAX_RECENT) : [];
    }
    _read(name, fallback) {
        try {
            return JSON.parse(fs.readFileSync(path.join(this.dir, name), 'utf8'));
        } catch (e) {
            return fallback;
        }
    }
    _write(name, value) {
        const file = path.join(this.dir, name);
        const tmp = `${file}.tmp`;
        try {
            fs.writeFileSync(tmp, JSON.stringify(value));
            fs.renameSync(tmp, file);
        } catch (e) {
            /* a full or missing folder: this session keeps what it has in memory */
        }
    }
    setQuality(q) {
        this.settings.quality = q;
        this._write('settings.json', this.settings);
    }
    setSubtitles(on) {
        this.settings.subtitles = on;
        this._write('settings.json', this.settings);
    }
    /* Send logs online. The id only tells one car's logs from another's, and says nothing about the car. */
    startLogs(now) {
        if (!this.settings.logsId) this.settings.logsId = `0000000${Math.floor(Math.random() * 0x100000000).toString(16)}`.slice(-8);
        this.settings.logsUntil = now + LOGS_S * 1000;
        this._write('settings.json', this.settings);
    }
    stopLogs() {
        this.settings.logsUntil = 0;
        this._write('settings.json', this.settings);
    }
    /* Seconds left: never more than one press gives, whatever the car's clock did. */
    logsLeft(now) {
        const left = Math.ceil((this.settings.logsUntil - now) / 1000);
        return left > 0 ? Math.min(left, LOGS_S) : 0;
    }
    /* Searches again in one press: typing in a car is the slow part. */
    addRecent(words) {
        this.recent = [words].concat(this.recent.filter((r) => r !== words)).slice(0, MAX_RECENT);
        this._write('recent.json', this.recent);
    }
    setInstance(url) {
        this.settings.instance = url;
        this._write('settings.json', this.settings);
    }
    /* The video on top of the history, with what is known of it. */
    remember(video) {
        const old = this.history.find((h) => h.id === video.id);
        const row = Object.assign({}, old, video, { at: Date.now() });
        this.history = [row].concat(this.history.filter((h) => h.id !== video.id)).slice(0, MAX_HISTORY);
        this._write('history.json', this.history);
    }
    /* Where a video in the history was left. */
    savePosition(id, pos, dur) {
        const row = this.history.find((h) => h.id === id);
        if (!row) return;
        row.pos = dur > 0 && pos > dur - NEAR_END_S ? 0 : pos;
        this._write('history.json', this.history);
    }
    startOf(id) {
        const row = this.history.find((h) => h.id === id);
        return row && row.pos > 0 ? row.pos : 0;
    }
    clearHistory() {
        this.history = [];
        this.recent = [];
        this._write('history.json', this.history);
        this._write('recent.json', this.recent);
    }
}

/* What a value holds, on one line, for a log. A template string says [object Object] of most objects and throws on some. This never
 * throws, so what is being logged cannot be what stops a shutdown. */
function describe(value) {
    const seen = new Set();
    const plain = (key, v) => {
        if (typeof v === 'symbol') return String(v);
        if (v === null || typeof v !== 'object') return v;
        if (seen.has(v)) return '[seen above]';
        seen.add(v);
        if (v instanceof Map || v instanceof Set) return Array.from(v);
        return v instanceof Error ? Object.assign({ name: v.name, message: v.message }, v) : v;
    };
    try {
        const json = typeof value === 'string' ? value : JSON.stringify(value, plain);
        return String(json === undefined ? value : json).replace(/\s+/g, ' ').slice(0, DESCRIBE_MAX);
    } catch (e) {
        return '(a value that cannot be read)';
    }
}

/* What the app has to say, in a file the log collector picks up (native/ytplay/README.md): written at once, so it is there
 * however the app ended. A log that cannot be written is no reason to stop anything. */
class AppLog {
    constructor(dir) {
        this.file = path.join(dir, 'app.log');
    }
    line(level, text) {
        try {
            if (fs.existsSync(this.file) && fs.statSync(this.file).size > LOG_MAX) fs.renameSync(this.file, `${this.file}.1`);
            fs.appendFileSync(this.file, `${new Date().toISOString()} ${level} ${String(text).slice(0, 2000)}\n`);
        } catch (e) {
            /* a full or missing folder */
        }
    }
    /* For Send logs online: the lines the player has not had yet, oldest first, and where that leaves things, for markSent once it
     * has them. Read from the file and not kept as they are written, so a crash's last line goes too, at the next start. null: none. */
    unsent() {
        let place = this._place();
        let name = this.file;
        try {
            const now = fs.statSync(this.file);
            const old = fs.existsSync(`${this.file}.1`) ? fs.statSync(`${this.file}.1`) : null;
            const was = (file) => this._head(file).startsWith(place.head || '');
            if (place.ino === now.ino && was(this.file)) {
                /* where it was */
            } else if (old && old.ino === place.ino && place.pos < old.size && was(`${this.file}.1`)) {
                name = `${this.file}.1`;
            } else {
                place = { ino: now.ino, pos: 0 };
            }
            const fd = fs.openSync(name, 'r');
            const buf = Buffer.alloc(UNSENT_BYTES);
            const got = fs.readSync(fd, buf, 0, UNSENT_BYTES, place.pos);
            fs.closeSync(fd);
            const end = buf.lastIndexOf(0x0a, got - 1) + 1;
            if (got <= 0 || end <= 0) return null;
            const lines = buf.toString('utf8', 0, end).split('\n').map((l) => l.trim()).filter((l) => l).map((l) => l.slice(0, 2000));
            return { lines, place: { ino: place.ino, pos: place.pos + end, head: this._head(name) } };
        } catch (e) {
            return null;
        }
    }
    markSent(place) {
        try {
            fs.writeFileSync(`${this.file}.sent`, JSON.stringify(place));
        } catch (e) {
            /* a full or missing folder: at worst a line goes twice */
        }
    }
    _head(file) {
        const fd = fs.openSync(file, 'r');
        const buf = Buffer.alloc(HEAD_BYTES);
        const got = fs.readSync(fd, buf, 0, HEAD_BYTES, 0);
        fs.closeSync(fd);
        return buf.toString('hex', 0, got);
    }
    _place() {
        try {
            const p = JSON.parse(fs.readFileSync(`${this.file}.sent`, 'utf8'));
            if (p && Number.isFinite(p.ino) && Number.isFinite(p.pos)) return p;
        } catch (e) {
            /* nothing sent yet */
        }
        return { ino: 0, pos: 0 };
    }
}

module.exports = { AppData, AppLog, describe, QUALITIES, MAX_HISTORY, MAX_RECENT, LOG_MAX, LOGS_S };
