'use strict';
/**
 * The app's screens: one frame of a page from the model, and what on it can be pressed, in focus order. No I/O.
 *
 *   frame(model, { rec, page, focus, scroll, videoWords }) -> { items, rows }
 *
 * Everything is laid out on the logical 1790 x 638 of iDrive 7's app area (src/drawn.js fits that to the box the renderer gives), except
 * the player, on o.size: FULL, its layer over iDrive's top bar, or the app area if the renderer refuses that.
 * rec: a kit Recorder, reset here. page: 'browse', 'search', 'results', 'player', 'settings' or 'signin'.
 * scroll: { list: cards scrolled, fractional, max }, kept by the caller and moved here to follow the focus.
 * videoWords(x, y, w, h): the VIDEO op's words for the box the frame is fitted into. controls: the player's controls show. jump: { dir, by },
 * a double tap's seek to show.
 * items: { x, y, w, h, r, label, act, proxy, box?, seekBar?, surface?, seeks?, ring? }; proxy false: for touch only, no HMI focus proxy.
 * surface: the player's whole layer, for src/drawn.js to tell a tap from a double tap; seeks: a double tap has somewhere to go. ring: where
 * the focus ring goes instead of round the item, null for nowhere.
 *
 * For a car: touch targets at least 80 px (about 12 mm on a 12.3-inch screen) with 24 px between them, text at least 25 px, one line
 * of cards the dial can walk, and a focus ring no one can miss. Inter only, at the sizes the fonts are baked at.
 */
const qrcodegen = require('./qrcodegen.js');

const W = 1790;
const H = 638;
const C = { bg: '#0B0D10', panel: '#1A1E25', dimPanel: '#12151A', raised: '#2A2F39', text: '#F5F6F8', soft: '#C9CED6', dim: '#AEB4BE', off: '#6E7581',
    ink: '#0B0D10', accent: '#FF5C4D', warn: '#F5B83D', track: '#3A404B', veil: '#000000B8', badge: '#000000D0', white: '#FFFFFF', black: '#000000', lit: '#FFFFFF24' };
const BOLD = { font: 'bold' };
const MARGIN = 24;
const BAR_Y = 16;
const BAR_H = 88;
const CARD_W = 540;
const CARD_THUMB_H = 304;
const CARD_STEP = 564;
const CARD_Y = 128;
const CARD_H = 438;
const MAX_ROWS = 24;
const CARDS_SHOWN = (W - MARGIN) / CARD_STEP;
const FULL = { w: 1812, h: 720 };        // the player: from the app area's left edge to the screen's right, over iDrive's top bar
const NAME_BAND_H = 96;
const BAR_BAND_H = 108;
const LIVE_BAND_H = 64;
const BAND_PAD = 24;
const SUBS_W = 272;
const DISC = 176;
const FOCUS_GAP = 8;
const FOCUS_WIDTH = 5;

function fmtTime(s) {
    const t = Math.max(0, Math.floor(s || 0));
    const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60;
    const ss = String(sec).padStart(2, '0');
    return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`;
}

/* How long ago, in the fewest words. */
function fmtAgo(when, now) {
    const s = (now || Date.now() / 1000) - when;
    if (!when || s < 0) return '';
    const unit = (n, name) => `${n} ${name}${n === 1 ? '' : 's'} ago`;
    if (s < 3600) return 'Just now';
    if (s < 86400) return unit(Math.floor(s / 3600), 'hour');
    if (s < 86400 * 7) return unit(Math.floor(s / 86400), 'day');
    if (s < 86400 * 31) return unit(Math.floor(s / (86400 * 7)), 'week');
    if (s < 86400 * 365) return unit(Math.floor(s / (86400 * 30)), 'month');
    return unit(Math.floor(s / (86400 * 365)), 'year');
}

/* What no atlas has and nobody misses, and the space before it: emoji and symbols, and the marks that only join or shape them. Each
 * would draw as a ?, as other letters the fonts lack still do: they say something is missing, and these say nothing. ♪ stays. */
const NOTHING = /\s*[\u{AD}\u{200B}-\u{200F}\u{202A}-\u{202E}\u{2060}-\u{206F}\u{20E3}\u{2300}-\u{23FF}\u{25A0}-\u{2669}\u{266B}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE00}-\u{FE0F}\u{1F000}-\u{1FAFF}\u{E0020}-\u{E007F}]/gu;

function drawable(text) {
    return String(text === undefined || text === null ? '' : text).replace(NOTHING, '').trim();
}

/* The text, cut with an ellipsis to fit width. */
function fit(rec, text, width, size, font) {
    const s = drawable(text);
    const opts = { font };
    if (rec.textWidth(s, size, opts) <= width) return s;
    let lo = 0, hi = s.length;
    while (lo < hi) {
        const mid = (lo + hi + 1) >> 1;
        if (rec.textWidth(`${s.slice(0, mid)}…`, size, opts) <= width) lo = mid;
        else hi = mid - 1;
    }
    return `${s.slice(0, lo).replace(/\s+$/, '')}…`;
}

/* The text in at most lines lines of width, the last cut with an ellipsis. */
function wrap(rec, text, width, size, font, lines) {
    const words = drawable(text).split(/\s+/).filter(Boolean);
    const out = [];
    let line = '';
    for (let i = 0; i < words.length; i++) {
        const next = line ? `${line} ${words[i]}` : words[i];
        if (rec.textWidth(next, size, { font }) <= width || !line) {
            line = next;
        } else {
            if (out.length === lines - 1) {
                out.push(fit(rec, words.slice(i - line.split(' ').length, words.length).join(' '), width, size, font));
                return out;
            }
            out.push(line);
            line = words[i];
        }
    }
    if (line) out.push(fit(rec, line, width, size, font));
    return out;
}

/* Words the kit has no call for (the VIDEO op) into the recording. */
function appendWords(rec, words) {
    rec._grow(words.length);
    rec.u.set(words, rec.n);
    rec.n += words.length;
}

/* What the speller's text is: a link or id to play, or words to search. */
function parseInput(text) {
    const s = String(text || '').replace(/[\r\n]+/g, ' ').trim();
    if (!s) return null;
    if (/^[A-Za-z0-9_-]{11}$/.test(s) && /[0-9_-]/.test(s)) return { kind: 'link', target: s };
    const bare = /^(?:https?:\/\/)?((?:www\.|m\.|music\.)?(?:youtube\.com|youtu\.be)\/\S+)$/i.exec(s);
    if (bare) return { kind: 'link', target: `https://${bare[1]}` };
    return { kind: 'query', query: s };
}

/* ---- icons: lines and arcs, so any size stays sharp ---- */

const icon = {
    search(rec, cx, cy, s, c) {
        const r = s * 0.31, w = s * 0.09, ox = cx - s * 0.08, oy = cy - s * 0.08;
        rec.arc(ox, oy, r - w / 2, r + w / 2, 0, 360, c);
        rec.line(ox + r * 0.72, oy + r * 0.72, cx + s * 0.42, cy + s * 0.42, w, c);
    },
    phone(rec, cx, cy, s, c) {
        rec.strokeRoundRect(cx - s * 0.26, cy - s * 0.44, s * 0.52, s * 0.88, s * 0.1, s * 0.07, c);
        rec.line(cx - s * 0.07, cy + s * 0.29, cx + s * 0.07, cy + s * 0.29, s * 0.07, c);
    },
    list(rec, cx, cy, s, c) {
        [-0.26, 0, 0.26].forEach((dy) => rec.line(cx - s * 0.38, cy + dy * s, cx + s * 0.38, cy + dy * s, s * 0.08, c));
    },
    sliders(rec, cx, cy, s, c) {
        const w = s * 0.07, x0 = cx - s * 0.42, x1 = cx + s * 0.42, y0 = cy - s * 0.2, y1 = cy + s * 0.2, r = s * 0.1;
        rec.line(x0, y0, cx + s * 0.1, y0, w, c);
        rec.arc(cx + s * 0.2, y0, r - w / 2, r + w / 2, 0, 360, c);
        rec.line(cx + s * 0.32, y0, x1, y0, w, c);
        rec.line(x0, y1, cx - s * 0.32, y1, w, c);
        rec.arc(cx - s * 0.2, y1, r - w / 2, r + w / 2, 0, 360, c);
        rec.line(cx - s * 0.1, y1, x1, y1, w, c);
    },
    pause(rec, cx, cy, s, c) {
        const w = s * 0.2, h = s * 0.64;
        rec.roundRect(cx - s * 0.27, cy - h / 2, w, h, 3, c);
        rec.roundRect(cx + s * 0.07, cy - h / 2, w, h, 3, c);
    },
    play(rec, cx, cy, s, c) {
        const x0 = cx - s * 0.24, x1 = cx + s * 0.34, h = s * 0.36;
        rec.quad([[x0, cy - h], [x1, cy], [x1, cy], [x0, cy + h]], c);
    },
    /* a circle's arc with an arrowhead: dir -1 back, 1 forward */
    jump(rec, cx, cy, s, c, dir) {
        const r = s * 0.36, w = s * 0.085;
        if (dir < 0) rec.arc(cx, cy, r - w / 2, r + w / 2, 300, 300 + 300, c);
        else rec.arc(cx, cy, r - w / 2, r + w / 2, 120, 120 + 300, c);
        const ax = cx + dir * r * 0.5, ay = cy - r * 0.866, h = s * 0.17;
        rec.quad([[ax - dir * h * 0.2, ay - h], [ax - dir * h * 1.2, ay], [ax - dir * h * 1.2, ay], [ax - dir * h * 0.2, ay + h]], c);
    },
    spinner(rec, cx, cy, s, c, turn) {
        const r = s * 0.42, w = s * 0.1, from = turn || 0;
        rec.arc(cx, cy, r - w / 2, r + w / 2, 0, 360, C.track);
        rec.arc(cx, cy, r - w / 2, r + w / 2, from, from + 90, c, { round: true });
    },
    warning(rec, cx, cy, s, c) {
        const w = s * 0.07, top = cy - s * 0.4, bottom = cy + s * 0.36, x = s * 0.44;
        rec.line(cx, top, cx - x, bottom, w, c);
        rec.line(cx, top, cx + x, bottom, w, c);
        rec.line(cx - x, bottom, cx + x, bottom, w, c);
        rec.line(cx, cy - s * 0.1, cx, cy + s * 0.1, w, c);
        rec.roundRect(cx - w * 0.6, cy + s * 0.18, w * 1.2, w * 1.2, w * 0.6, c);
    },
    done(rec, cx, cy, s, c) {
        const r = s * 0.42, w = s * 0.07;
        rec.arc(cx, cy, r - w / 2, r + w / 2, 0, 360, c);
        rec.line(cx - s * 0.18, cy + s * 0.02, cx - s * 0.04, cy + s * 0.16, w, c);
        rec.line(cx - s * 0.04, cy + s * 0.16, cx + s * 0.2, cy - s * 0.12, w, c);
    },
    clock(rec, cx, cy, s, c) {
        const r = s * 0.42, w = s * 0.07;
        rec.arc(cx, cy, r - w / 2, r + w / 2, 0, 360, c);
        rec.line(cx, cy - s * 0.22, cx, cy, w, c);
        rec.line(cx, cy, cx + s * 0.15, cy + s * 0.1, w, c);
    },
    offline(rec, cx, cy, s, c) {
        const w = s * 0.07;
        [0.42, 0.28, 0.14].forEach((r) => rec.arc(cx, cy + s * 0.22, s * r - w / 2, s * r + w / 2, 315, 405, c));
        rec.roundRect(cx - w, cy + s * 0.18, w * 2, w * 2, w, c);
        rec.line(cx - s * 0.38, cy - s * 0.38, cx + s * 0.38, cy + s * 0.38, w, c);
    }
};

/* ---- parts ---- */

function button(rec, items, b) {
    const r = b.r === undefined ? 24 : b.r;
    rec.roundRect(b.x, b.y, b.w, b.h, r, b.primary ? C.text : C.raised);
    const color = b.primary ? C.ink : C.text;
    const size = b.size || 33;
    if (b.left) rec.text(fit(rec, b.text, b.w - 2 * b.left, size, 'bold'), b.x + b.left, b.y + b.h / 2 + size * 0.36, size, color, BOLD);
    else rec.text(b.text, b.x + b.w / 2, b.y + b.h / 2 + size * 0.36, size, color, { font: 'bold', align: 'center' });
    items.push({ x: b.x, y: b.y, w: b.w, h: b.h, r, label: b.text, act: b.act });
}

function pill(rec, items, x, text, on, act) {
    const w = Math.ceil(rec.textWidth(text, 33, BOLD)) + 72;
    if (on) rec.roundRect(x, BAR_Y, w, BAR_H, BAR_H / 2, C.raised);
    rec.text(text, x + w / 2, BAR_Y + BAR_H / 2 + 12, 33, on ? C.text : C.dim, { font: 'bold', align: 'center' });
    items.push({ x, y: BAR_Y, w, h: BAR_H, r: BAR_H / 2, label: text, act });
    return x + w + 12;
}

/* The field-like pill: an icon, then words. */
function field(rec, items, x, w, text, drawIcon, act) {
    const tw = w || Math.ceil(rec.textWidth(text, 33, BOLD)) + 124;
    rec.roundRect(x, BAR_Y, tw, BAR_H, BAR_H / 2, C.panel);
    drawIcon(rec, x + 54, BAR_Y + BAR_H / 2, 40, C.text);
    rec.text(fit(rec, text, tw - 124, 33, 'bold'), x + 88, BAR_Y + BAR_H / 2 + 12, 33, C.text, BOLD);
    items.push({ x, y: BAR_Y, w: tw, h: BAR_H, r: BAR_H / 2, label: text, act });
    return x + tw + 12;
}

function card(rec, m, x, row) {
    const img = m.thumbs && m.thumbs(row.thumb || row.id);
    if (img) rec.image(img, x, CARD_Y, CARD_W, CARD_THUMB_H, 16);
    else rec.roundRect(x, CARD_Y, CARD_W, CARD_THUMB_H, 16, C.panel);
    const corner = row.playlist ? `${row.count} video${row.count === 1 ? '' : 's'}` : row.duration ? fmtTime(row.duration) : '';
    if (corner) {
        const bw = rec.textWidth(corner, 25, BOLD) + 24;
        rec.roundRect(x + CARD_W - 12 - bw, CARD_Y + CARD_THUMB_H - 52, bw, 40, 8, C.badge);
        rec.text(corner, x + CARD_W - 24, CARD_Y + CARD_THUMB_H - 23, 25, C.text, { font: 'bold', align: 'right' });
    }
    if (row.left > 0) {
        rec.roundRect(x, CARD_Y + CARD_THUMB_H - 8, CARD_W, 8, 4, '#FFFFFF44');
        rec.roundRect(x, CARD_Y + CARD_THUMB_H - 8, CARD_W * Math.min(1, row.left), 8, 4, C.accent);
    }
    const lines = wrap(rec, row.title || row.id, CARD_W, 33, 'bold', 2);
    lines.forEach((line, i) => rec.text(line, x, CARD_Y + CARD_THUMB_H + 42 + i * 40, 33, C.text, BOLD));
    const meta = row.meta || [row.channel, fmtAgo(row.published)].filter(Boolean).join('  ·  ');
    rec.text(fit(rec, meta, CARD_W, 25), x, CARD_Y + CARD_THUMB_H + 42 + (lines.length - 1) * 40 + 40, 25, C.dim);
}

/* The one line of cards the dial walks along. */
function rail(rec, m, o, rows, items) {
    const list = rows.slice(0, MAX_ROWS);
    const first = items.length;
    const box = { x: 0, y: CARD_Y - FOCUS_GAP - FOCUS_WIDTH, w: W, h: H - CARD_Y + FOCUS_GAP + FOCUS_WIDTH };
    const shown = CARDS_SHOWN;
    const max = Math.max(0, list.length - shown);
    let top = Math.max(0, Math.min(max, (o.scroll && o.scroll.list) || 0));
    const at = o.focus - first;
    if (at >= 0 && at < list.length) {
        if (at < top) top = at;
        else if (at + 1 > top + shown) top = at + 1 - shown;
    }
    if (o.scroll) {
        o.scroll.list = top;
        o.scroll.max = max;
    }
    rec.clip(box.x, box.y, box.w, box.h);
    list.forEach((row, i) => {
        const x = MARGIN + (i - top) * CARD_STEP;
        items.push({ x, y: CARD_Y, w: CARD_W, h: CARD_H, r: 16, label: row.title || row.id, box,
            act: row.playlist ? { do: 'playlist', row } : { do: 'open', video: row } });
        if (x + CARD_W >= 0 && x <= W) card(rec, m, x, row);
    });
    rec.noclip();
    return list;
}

/* Words where the cards would be: loading, empty, or what went wrong, with what can be done. */
function railMessage(rec, items, words, retry) {
    rec.text(fit(rec, words, W - 2 * MARGIN, 33, 'bold'), W / 2, 300, 33, C.soft, { font: 'bold', align: 'center' });
    if (retry) button(rec, items, { x: W / 2 - 150, y: 340, w: 300, h: 104, text: 'Try again', act: { do: 'reload' } });
}

function feedOf(m) {
    if (m.tab === 'history') return { rows: historyRows(m), loading: false, error: '' };
    return (m.feeds && m.feeds[m.tab]) || { rows: [], loading: true, error: '' };
}

function historyRows(m) {
    return (m.history || []).map((h) => {
        const leftS = h.pos > 0 && h.duration > 0 ? h.duration - h.pos : 0;
        return Object.assign({}, h, leftS > 0 ? { left: h.pos / h.duration, meta: `Keep watching  ·  ${fmtTime(leftS)} left` } : { meta: h.channel || '' });
    });
}

/* ---- browse ---- */

const EMPTY = { home: 'Nothing new from your channels yet', subs: 'No new videos from your subscriptions', playlists: 'You have no playlists yet',
    liked: 'You have not liked any videos yet', history: 'Nothing watched yet' };
const TABS = [['home', 'Home'], ['subs', 'Subscriptions'], ['playlists', 'Playlists'], ['liked', 'Liked'], ['history', 'History']];

/* "Updated 3 min ago", for a list fetched at ms by this clock; nothing for a time still to come, as after the clock went back. */
function updated(at, now) {
    const t = now || Date.now(), s = (t - at) / 1000;
    if (!at || s < 0) return '';
    if (s < 60) return 'Updated just now';
    if (s < 3600) return `Updated ${Math.floor(s / 60)} min ago`;
    return `Updated ${fmtAgo(at / 1000, t / 1000)}`;
}

/* Under the cards of a tab with some: how old they are and how to have new ones, or that new ones are on their way, or did not come. */
function feedLine(rec, m, feed) {
    const name = (TABS.find(([tab]) => tab === m.tab) || [])[1];
    if (!name || m.tab === 'history' || !(feed.rows && feed.rows.length)) return;
    const words = feed.loading ? 'Refreshing…' : feed.error ? `Could not refresh: ${feed.error}` :
        [updated(feed.at), `Press ${name} again to refresh`].filter(Boolean).join('  ·  ');
    rec.text(fit(rec, words, W - 2 * MARGIN, 25), MARGIN, H - 28, 25, feed.error && !feed.loading ? C.warn : C.dim);
}

function browse(rec, m, o) {
    const items = [];
    rec.fillRect(0, 0, W, H, C.bg);
    if (!m.account && !(m.history || []).length) return firstRun(rec, m, o, items);

    let x = field(rec, items, MARGIN, 0, 'Search', icon.search, { do: 'searchPage' });
    if (m.account) {
        TABS.forEach(([tab, text]) => {
            x = pill(rec, items, x, text, m.tab === tab, { do: 'tab', tab });
        });
        const ax = W - MARGIN - BAR_H;
        rec.roundRect(ax, BAR_Y, BAR_H, BAR_H, BAR_H / 2, C.raised);
        rec.text(String(m.account.name || '?').charAt(0).toUpperCase(), ax + BAR_H / 2, BAR_Y + BAR_H / 2 + 12, 33, C.text, { font: 'bold', align: 'center' });
        items.push({ x: ax, y: BAR_Y, w: BAR_H, h: BAR_H, r: BAR_H / 2, label: 'Settings', act: { do: 'settings' } });
    } else {
        x = pill(rec, items, x, 'History', true, { do: 'tab', tab: 'history' });
        const sx = W - MARGIN - BAR_H;
        rec.roundRect(sx, BAR_Y, BAR_H, BAR_H, BAR_H / 2, C.raised);
        icon.sliders(rec, sx + BAR_H / 2, BAR_Y + BAR_H / 2, 44, C.text);
        const label = 'Sign in';
        const lw = Math.ceil(rec.textWidth(label, 33, BOLD)) + 124;
        field(rec, items, sx - 12 - lw, lw, label, icon.phone, { do: 'signin' });
        items.push({ x: sx, y: BAR_Y, w: BAR_H, h: BAR_H, r: BAR_H / 2, label: 'Settings', act: { do: 'settings' } });
    }

    const feed = feedOf(m);
    if (feed.rows && feed.rows.length) {
        rail(rec, m, o, feed.rows, items);
        feedLine(rec, m, feed);
    } else if (feed.error) railMessage(rec, items, feed.error, true);
    else if (feed.loading) railMessage(rec, items, 'Loading…');
    else railMessage(rec, items, EMPTY[m.tab] || 'Nothing here yet');
    return items;
}

function firstRun(rec, m, o, items) {
    const pw = (W - 3 * MARGIN) / 2, ph = H - 2 * MARGIN, settingsH = 104;
    [[MARGIN, ph, C.raised, 'Search', 'Words or a video link, typed with the iDrive', icon.search, { do: 'searchPage' }],
        [MARGIN * 2 + pw, ph - settingsH - MARGIN, C.panel, 'Sign in', 'Home, subscriptions and playlists, by phone', icon.phone, { do: 'signin' }]].forEach(([x, h, bg, title, sub, drawIcon, act]) => {
        rec.roundRect(x, MARGIN, pw, h, 24, bg);
        drawIcon(rec, x + 92, MARGIN + 92, 88, C.text);
        rec.text(title, x + 48, MARGIN + h - 112, 58, C.text, BOLD);
        rec.text(fit(rec, sub, pw - 96, 31), x + 48, MARGIN + h - 56, 31, C.soft);
        items.push({ x, y: MARGIN, w: pw, h, r: 24, label: title, act });
    });
    // for whoever gets no further than this page: Send logs online is there
    button(rec, items, { x: MARGIN * 2 + pw, y: MARGIN + ph - settingsH, w: pw, h: settingsH, text: 'Settings', act: { do: 'settings' } });
    return items;
}

/* ---- search ---- */

function search(rec, m) {
    const items = [];
    rec.fillRect(0, 0, W, H, C.bg);
    rec.roundRect(MARGIN, MARGIN, W - 2 * MARGIN, 120, 24, C.text);
    icon.search(rec, MARGIN + 72, MARGIN + 60, 52, C.ink);
    rec.text('Type a new search', MARGIN + 120, MARGIN + 76, 44, C.ink, BOLD);
    items.push({ x: MARGIN, y: MARGIN, w: W - 2 * MARGIN, h: 120, r: 24, label: 'Type a new search', act: { do: 'type' } });
    const recent = (m.recent || []).slice(0, 6);
    if (recent.length) {
        rec.text('Search again', MARGIN, 196, 25, C.dim);
        const cw = (W - 4 * MARGIN) / 3;
        recent.forEach((words, i) => {
            button(rec, items, { x: MARGIN + (i % 3) * (cw + MARGIN), y: 216 + Math.floor(i / 3) * 144, w: cw, h: 120, text: words, left: 36, act: { do: 'query', words } });
        });
    }
    rec.text('Typing opens the iDrive\'s own speller', MARGIN, H - 28, 25, C.dim);
    return items;
}

function results(rec, m, o) {
    const items = [];
    const list = m.list || { rows: [], loading: true };
    rec.fillRect(0, 0, W, H, C.bg);
    const count = list.rows && list.rows.length ? `${list.rows.length} video${list.rows.length === 1 ? '' : 's'}` : '';
    const cw = count ? rec.textWidth(count, 25) + 48 : 0;
    field(rec, items, MARGIN, W - 2 * MARGIN - cw, list.title || '', list.playlist ? icon.list : icon.search, list.playlist ? { do: 'reload' } : { do: 'type' });
    if (count) rec.text(count, W - MARGIN - 16, BAR_Y + BAR_H / 2 + 9, 25, C.dim, { align: 'right' });
    if (list.rows && list.rows.length) rail(rec, m, o, list.rows, items);
    else if (list.error) railMessage(rec, items, list.error, true);
    else if (list.loading) railMessage(rec, items, list.playlist ? 'Loading…' : 'Searching…');
    else railMessage(rec, items, `Nothing found for ${list.title}`);
    return items;
}

/* ---- the player: controls in the space a 16:9 picture leaves anyway, so nothing covers the picture ---- */

const SLOW_S = 15;      // a part of a start this long, or a stall, is worth saying, and another try is worth offering
const QUIET_S = 3;      // a seek shorter than this says nothing over its picture

/* A start or a seek with no picture yet. Only a hold has an end anyone can know. For the rest the seconds go up, and past SLOW_S the
 * page says so and offers another try while the player goes on: fetching new video cookies makes a start slow, and it still works. */
function startStatus(p) {
    if (p.online === false) return { icon: icon.offline, title: 'Waiting for internet', words: 'The video goes on once your connection is back', color: C.warn, idle: true };
    if (p.wait > 0) return { icon: icon.spinner, turn: p.turn, title: `Starts in ${Math.ceil(p.wait)} s`, words: 'YouTube holds some videos back before they start', color: C.text, idle: true };
    const s = Math.floor(p.waited || 0), retry = s >= SLOW_S;
    if (p.state === 'stalled') return { icon: icon.offline, title: 'Can\'t reach the video', words: `Still trying: ${s} s so far`, color: C.warn, idle: true, retry };
    const title = p.state === 'resolving' ? 'Finding the video' : p.frames ? 'Loading' : 'Opening the video';
    const words = retry ? `Taking longer than usual: ${s} s so far` : s ? `${s} s so far` : '';
    return { icon: icon.spinner, turn: p.turn, title, words, color: C.text, idle: true, retry };
}

/* A seek: this video's frames have been shown, and the last of them stays up until the next. For a moment only the disc's spinner says so.
 * After that, or at once with no internet or a hold, what a start would say goes over the picture. */
function seekStatus(p) {
    const quiet = p.online !== false && !(p.wait > 0) && (p.waited || 0) < QUIET_S;
    return Object.assign(startStatus(p), { idle: false, veil: true, quiet, spins: true });
}

/* A video that has played and lost its stream, with its last frame under the veil. As with a start, a hold and no internet are not its fault. */
function stallStatus(p) {
    const stall = { icon: icon.offline, title: 'Reconnecting', color: C.warn, veil: true };
    if (p.online === false) return Object.assign(stall, { title: 'Waiting for internet', words: 'The video goes on from here once your connection is back' });
    if (p.wait > 0) return Object.assign(stall, { words: `The video goes on from here in ${Math.ceil(p.wait)} s` });
    const s = Math.floor(p.waited || 0), retry = s >= SLOW_S;
    return Object.assign(stall, { words: retry ? `Taking longer than usual: ${s} s so far` : 'The video goes on from here in a moment', retry });
}

function statusOf(p) {
    if (!p) return null;
    switch (p.state) {
    case 'resolving': case 'buffering':
        return p.state === 'buffering' && p.frames > 0 ? seekStatus(p) : startStatus(p);
    case 'stalled':
        return p.frames === 0 ? startStatus(p) : stallStatus(p);
    case 'ended':
        return { icon: icon.done, title: 'That was the end', words: 'Tap to watch it again', color: C.text, veil: true };
    default:
        return null;
    }
}

function message(rec, box, s) {
    const cx = box.x + box.w / 2, cy = box.y + box.h / 2;
    s.icon(rec, cx, cy - 100, 96, s.color, s.turn);
    rec.text(fit(rec, s.title, box.w - 96, 44, 'bold'), cx, cy + 16, 44, C.text, { font: 'bold', align: 'center' });
    if (s.words) rec.text(fit(rec, s.words, box.w - 96, 31), cx, cy + 68, 31, C.soft, { align: 'center' });
}

/* Where the VIDEO op puts the frame in a layer of this size. A frame not seen yet counts as 16:9. */
function pictureBox(size, p) {
    const aspect = p.w > 0 && p.h > 0 ? p.w / p.h : 16 / 9;
    const w = Math.min(size.w, size.h * aspect), h = w / aspect;
    return { x: (size.w - w) / 2, y: (size.h - h) / 2, w, h };
}

function player(rec, m, o) {
    const p = m.player || {};
    const size = o.size || { w: W, h: H };
    const items = [];
    rec.fillRect(0, 0, size.w, size.h, C.black);
    if (p.state === 'error') return playerError(rec, p, items, size);

    const s = statusOf(p);
    if (o.videoWords && !(s && s.idle)) appendWords(rec, o.videoWords(0, 0, size.w, size.h));
    const said = s && !s.quiet;
    if (said && s.veil) rec.fillRect(0, 0, size.w, size.h, C.veil);

    /* never narrower than a 16:9 picture: a vertical video's own width would make a bar too short to aim at */
    const pic = pictureBox(size, p);
    const w = Math.max(pic.w, Math.min(size.w, size.h * 16 / 9));
    const box = { x: (size.w - w) / 2, y: pic.y, w, h: pic.h };
    if (said) message(rec, box, s);

    /* first, so everything else is hit before it, and with the one proxy, so the HMI's focus stays and the dial can seek */
    const retry = s && s.retry;
    const paused = p.state === 'paused' || p.state === 'ended';
    const surface = { x: 0, y: 0, w: size.w, h: size.h, r: 0, label: retry ? 'Try again' : paused ? 'Play' : 'Pause', act: { do: retry ? 'retry' : 'playpause' }, surface: true, ring: null,
        /* a seek buffers too, and the next press should still count: only a video not found yet has nowhere to go */
        seeks: !retry && p.state !== 'resolving' && !p.live && p.state !== 'stalled' };
    items.push(surface);
    if (retry) surface.ring = tryAgain(rec, box);

    if (o.jump) jumpMark(rec, size, o.jump);
    if (!said && p.subLine) subtitleLine(rec, box, p.subLine, !o.controls ? 0 : p.live ? LIVE_BAND_H : BAR_BAND_H);
    if (!o.controls) return items;
    nameBand(rec, items, box, p);
    if (!said && !o.jump) {
        const r = DISC / 2, cx = box.x + box.w / 2, cy = box.y + box.h / 2;
        rec.roundRect(cx - r, cy - r, DISC, DISC, r, C.veil);
        (s ? icon.spinner : paused ? icon.play : icon.pause)(rec, cx, cy, 96, C.text, p.turn);
        surface.ring = { x: cx - r, y: cy - r, w: DISC, h: DISC, r };
    }
    barBand(rec, items, box, p);
    return items;
}

/* Under a message, for what a tap on the picture and the dial's push do then. */
function tryAgain(rec, box) {
    const w = 320, h = 88, x = box.x + (box.w - w) / 2, y = box.y + box.h / 2 + 100;
    rec.roundRect(x, y, w, h, 24, C.text);
    rec.text('Try again', x + w / 2, y + 56, 33, C.ink, { font: 'bold', align: 'center' });
    return { x, y, w, h, r: 24 };
}

/* The video's name, why there is no sound if there is none, and Subtitles: touch only, like the bar, so the dial can seek. */
function nameBand(rec, items, box, p) {
    const state = p.subs || 'off', lit = state === 'on' || state === 'loading', failed = p.audio === 'failed';
    const x = box.x + BAND_PAD, bx = box.x + box.w - BAND_PAD - SUBS_W, by = box.y + 8, room = bx - BAND_PAD - x;
    rec.fillRect(box.x, box.y, box.w, NAME_BAND_H, C.veil);
    rec.text(fit(rec, p.title || '', room, 33, 'bold'), x, box.y + (failed ? 42 : 60), 33, C.text, BOLD);
    if (failed) rec.text(fit(rec, `No sound: ${p.audioError || 'it did not start'}`, room, 25), x, box.y + 78, 25, C.warn);
    rec.roundRect(bx, by, SUBS_W, 80, 24, lit ? C.raised : C.panel);
    rec.text(`Subtitles: ${state === 'loading' ? '…' : state}`, bx + SUBS_W / 2, by + 51, 31, state === 'failed' ? C.warn : lit ? C.text : C.dim, { font: 'bold', align: 'center' });
    items.push({ x: bx, y: by, w: SUBS_W, h: 80, r: 24, label: 'Subtitles', proxy: false, act: { do: 'subtitles' } });
}

/* The time and the position bar, on the picture's bottom edge. The bar's target runs to that edge, and is 80 px tall. */
function barBand(rec, items, box, p) {
    const bottom = box.y + box.h, x = box.x + BAND_PAD, pw = box.w - 2 * BAND_PAD;
    if (p.live) {
        rec.fillRect(box.x, bottom - LIVE_BAND_H, box.w, LIVE_BAND_H, C.veil);
        rec.text('LIVE', x, bottom - 20, 33, C.accent, BOLD);
        return;
    }
    const top = bottom - BAR_BAND_H, trackY = bottom - 28;
    rec.fillRect(box.x, top, box.w, BAR_BAND_H, C.veil);
    const nw = rec.text(fmtTime(p.pos), x, top + 40, 33, C.text, BOLD);
    if (p.dur > 0) rec.text(`/ ${fmtTime(p.dur)}`, x + nw + 12, top + 40, 33, C.dim);
    rec.roundRect(x, trackY - 7, pw, 14, 7, C.track);
    const frac = p.dur > 0 ? Math.max(0, Math.min(1, p.pos / p.dur)) : 0;
    if (frac > 0) {
        rec.roundRect(x, trackY - 7, pw * frac, 14, 7, C.accent);
        rec.roundRect(x + pw * frac - 18, trackY - 18, 36, 36, 18, C.text);
    }
    if (p.dur > 0 && p.state !== 'resolving') {
        items.push({ x, y: bottom - 80, w: pw, h: 80, r: 0, label: 'Position', proxy: false, seekBar: true, act: { do: 'seekTo', dur: p.dur } });
    }
}

/* A double tap's seek: that half of the layer lit, and how far it went. */
function jumpMark(rec, size, jump) {
    const half = size.w / 2, cx = jump.dir < 0 ? half / 2 : half * 1.5, cy = size.h / 2, r = DISC / 2;
    rec.fillRect(jump.dir < 0 ? 0 : half, 0, half, size.h, C.lit);
    rec.roundRect(cx - r, cy - r, DISC, DISC, r, C.veil);
    icon.jump(rec, cx, cy - 22, 80, C.text, jump.dir);
    rec.text(`${jump.by} s`, cx, cy + 58, 33, C.text, { font: 'bold', align: 'center' });
}

/* A line of subtitles at the foot of the picture, above lift px of controls, each row on a dark band of its own, so it reads over anything. */
function subtitleLine(rec, box, text, lift) {
    const size = 33, step = 46, pad = 16;
    const lines = wrap(rec, text, box.w - 2 * MARGIN - 2 * pad, size, 'bold', 3);
    lines.forEach((line, i) => {
        const y = box.y + box.h - lift - MARGIN - (lines.length - i) * step;
        const w = rec.textWidth(line, size, BOLD) + 2 * pad;
        rec.roundRect(box.x + (box.w - w) / 2, y, w, step, 8, C.badge);
        rec.text(line, box.x + box.w / 2, y + 34, size, C.text, { font: 'bold', align: 'center' });
    });
}

function playerError(rec, p, items, size) {

    const words = p.error || 'This video will not play';
    const cx = size.w / 2, top = (size.h - H) / 2;
    icon.warning(rec, cx, top + 170, 96, C.warn);
    rec.text(fit(rec, words, size.w - 200, 44, 'bold'), cx, top + 290, 44, C.text, { font: 'bold', align: 'center' });
    button(rec, items, { x: cx - 372, y: top + 360, w: 400, h: 104, text: 'Back to the list', primary: true, act: { do: 'leave' } });
    button(rec, items, { x: cx + 52, y: top + 360, w: 320, h: 104, text: 'Try again', act: { do: 'playpause' } });
    return items;
}

/* ---- settings ---- */

const ROW_H = 108;
const ROW_BUTTON_H = 84;

function settingRow(rec, y, title, sub) {
    rec.roundRect(MARGIN, y, W - 2 * MARGIN, ROW_H, 24, C.panel);
    rec.text(fit(rec, title, 840, 33, 'bold'), MARGIN + 28, y + 48, 33, C.text, BOLD);
    rec.text(fit(rec, sub, 1180, 25), MARGIN + 28, y + 86, 25, C.dim);
}

function logsWords(l) {
    const hours = `${l.hours} more hour${l.hours === 1 ? '' : 's'}`;
    const how = `${l.sent} line${l.sent === 1 ? '' : 's'} sent${l.note && l.note !== 'all sent' ? `, ${l.note}` : ''}`;
    return `On for ${hours}. Your ID is ${l.id}. ${how}`;
}

function settings(rec, m) {
    const s = m.settings || {};
    const items = [];
    rec.fillRect(0, 0, W, H, C.bg);
    const right = W - MARGIN - 28, btn = 220;
    const row = (i) => MARGIN + i * 118;
    const rowButton = (i, b) => button(rec, items, Object.assign({ y: row(i) + (ROW_H - ROW_BUTTON_H) / 2, h: ROW_BUTTON_H }, b));
    settingRow(rec, row(0), m.account ? m.account.name : 'Not signed in', m.account ? 'Signed in' : 'Your Home, subscriptions and playlists');
    rowButton(0, { x: right - btn, w: btn, text: m.account ? 'Sign out' : 'Sign in', act: { do: m.account ? 'signout' : 'signin' } });

    settingRow(rec, row(1), 'Picture quality', 'Lower it if the video stutters');
    [720, 480, 360].forEach((q, i) => {
        const on = (s.quality || 720) === q;
        rowButton(1, { x: right - (3 - i) * 160 - (2 - i) * 24, w: 160, text: `${q}p`, primary: on, act: { do: 'quality', q } });
    });

    settingRow(rec, row(2), 'Where videos come from', s.instance ? `The server at ${s.instance}` : 'Directly from YouTube, using yt-dlp on this car');
    rowButton(2, { x: right - btn, w: btn, text: 'Change', act: { do: 'server' } });

    const n = (m.history || []).length;
    settingRow(rec, row(3), 'History in this app', n ? `${n} video${n === 1 ? '' : 's'}, kept on this car only` : 'Kept on this car only');
    rowButton(3, { x: right - btn, w: btn, text: 'Clear', act: { do: 'clear' } });

    settingRow(rec, row(4), 'Send logs online', m.logs ? logsWords(m.logs) : 'Sends this app\'s logs to its developer for 24 hours, without your account or video names');
    rowButton(4, { x: right - btn, w: btn, text: m.logs ? 'Turn off' : 'Turn on', primary: !!m.logs, act: { do: 'logs' } });
    if (m.settingsNote) rec.text(fit(rec, m.settingsNote, W - 2 * MARGIN, 25), MARGIN, H - 8, 25, C.warn);
    return items;
}

/* ---- signing in, with a phone ---- */

let qrCache = { text: null, runs: null, size: 0 };
function qrRuns(text) {
    if (qrCache.text === text) return qrCache;
    const code = qrcodegen.QrCode.encodeText(text, qrcodegen.QrCode.Ecc.MEDIUM);
    const runs = [];
    for (let y = 0; y < code.size; y++) {
        let start = -1;
        for (let x = 0; x <= code.size; x++) {
            const dark = x < code.size && code.getModule(x, y);
            if (dark && start < 0) start = x;
            if (!dark && start >= 0) {
                runs.push([start, y, x - start]);
                start = -1;
            }
        }
    }
    qrCache = { text, runs, size: code.size };
    return qrCache;
}

function drawQr(rec, x, y, side, text) {
    const q = qrRuns(text);
    rec.roundRect(x, y, side, side, 24, C.white);
    const px = Math.floor((side - 40) / q.size), inset = (side - px * q.size) / 2;
    q.runs.forEach(([cx, cy, n]) => rec.fillRect(x + inset + cx * px, y + inset + cy * px, n * px, px, C.ink));
}

function signin(rec, m) {
    const items = [];
    rec.fillRect(0, 0, W, H, C.bg);
    const s = m.signin || { step: 'offer' };
    if (s.step === 'code') return signinCode(rec, s, items);
    if (s.step === 'offer') return signinOffer(rec, items);
    const box = { x: 0, y: -60, w: W, h: H };
    if (s.step === 'done') {
        message(rec, box, { icon: icon.done, title: 'You\'re signed in', words: s.name || '', color: C.text });
        button(rec, items, { x: W / 2 - 240, y: 430, w: 480, h: 104, text: 'Go to Home', primary: true, act: { do: 'signinHome' } });
        return items;
    }
    if (s.step === 'waiting') {
        message(rec, box, { icon: icon.spinner, title: 'Asking Google for a code', words: '', color: C.text });
        button(rec, items, { x: W / 2 - 120, y: 430, w: 240, h: 104, text: 'Cancel', act: { do: 'leave' } });
        return items;
    }
    const failed = {
        expired: { title: 'That code ran out', words: 'You can keep using the app without signing in', again: 'Get a new code' },
        denied: { title: 'Access was not allowed', words: 'You can keep using the app without signing in', again: 'Try again' },
        nosetup: { title: 'Sign-in is not set up in this build', words: 'It needs a Google client id: see the player tool\'s README', again: '' },
        error: { title: s.why || 'That did not work', words: 'You can keep using the app without signing in', again: 'Try again' }
    }[s.step] || { title: 'That did not work', words: '', again: 'Try again' };
    message(rec, box, { icon: s.step === 'expired' ? icon.clock : icon.warning, title: failed.title, words: failed.words, color: C.warn });
    if (failed.again) {
        button(rec, items, { x: W / 2 - 332, y: 430, w: 400, h: 104, text: failed.again, primary: true, act: { do: 'signinStart' } });
        button(rec, items, { x: W / 2 + 92, y: 430, w: 240, h: 104, text: 'Not now', act: { do: 'leave' } });
    } else {
        button(rec, items, { x: W / 2 - 120, y: 430, w: 240, h: 104, text: 'Back', primary: true, act: { do: 'leave' } });
    }
    return items;
}

function signinOffer(rec, items) {
    const x = 48, pw = (W - 2 * x - MARGIN) / 2;
    rec.text('Sign in with your phone', x, 84, 58, C.text, BOLD);
    rec.roundRect(x, 128, pw, 280, 24, C.panel);
    rec.roundRect(x + pw + MARGIN, 128, pw, 280, 24, C.dimPanel);
    rec.text('You get', x + 36, 180, 25, C.dim, BOLD);
    ['Your subscriptions', 'Your playlists and liked videos', 'A Home page built from them'].forEach((line, i) => {
        rec.text(line, x + 36, 240 + i * 62, 33, C.text, BOLD);
    });
    rec.text('YouTube does not share these with apps', x + pw + MARGIN + 36, 180, 25, C.dim, BOLD);
    ['YouTube\'s own picks for you', 'Watch later', 'Your YouTube history'].forEach((line, i) => {
        rec.text(line, x + pw + MARGIN + 36, 240 + i * 62, 33, C.dim);
    });
    button(rec, items, { x, y: H - 136, w: 360, h: 104, text: 'Continue', primary: true, act: { do: 'signinStart' } });
    button(rec, items, { x: x + 384, y: H - 136, w: 240, h: 104, text: 'Not now', act: { do: 'leave' } });
    rec.text('Sign in while parked.', x + 656, H - 92, 25, C.dim);
    rec.text('This app keeps its own history either way.', x + 656, H - 58, 25, C.dim);
    return items;
}

function signinCode(rec, s, items) {
    const side = 542, x = 48, y = 48, tx = 638;
    drawQr(rec, x, y, side, s.url || 'https://www.google.com/device');
    const host = String(s.url || '').replace(/^https?:\/\/(www\.)?/, '');
    rec.text('1', tx, 84, 33, C.dim);
    rec.text(`Scan this with your phone, or open ${host}`, tx + 44, 84, 33, C.text, BOLD);
    rec.text('2', tx, 156, 33, C.dim);
    rec.text('Enter this code', tx + 44, 156, 33, C.text, BOLD);
    rec.text(s.code || '', tx + 44, 252, 77, C.text, { font: 'bold', spacing: 3 });
    rec.text('3', tx, 328, 33, C.dim);
    rec.text('Choose your account and allow access', tx + 44, 328, 33, C.text, BOLD);
    button(rec, items, { x: tx, y: H - 152, w: 240, h: 104, text: 'Cancel', act: { do: 'leave' } });
    icon.spinner(rec, tx + 296, H - 100, 44, C.text);
    rec.text('Waiting for your phone.', tx + 336, H - 110, 25, C.soft);
    if (s.minutes) rec.text(`This code works for ${s.minutes} more minute${s.minutes === 1 ? '' : 's'}.`, tx + 336, H - 76, 25, C.soft);
    return items;
}

const PAGES = { browse, search, results, player, settings, signin };

function frame(m, o) {
    const rec = o.rec;
    rec.reset();
    rec.clear([0, 0, 0, 0]);
    const items = PAGES[o.page](rec, m, o);
    const f = items[o.focus];
    const ring = f && f.ring !== undefined ? f.ring : f;
    if (ring && f.proxy !== false && !(f.box && (f.x + f.w < f.box.x || f.x > f.box.x + f.box.w))) {
        const g = FOCUS_GAP;
        rec.strokeRoundRect(ring.x - g, ring.y - g, ring.w + 2 * g, ring.h + 2 * g, ring.r + g, FOCUS_WIDTH, C.white);
    }
    return { items };
}

const inside = (r, x, y) => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h;

/* The item under (x, y), or -1: a card only where its row shows it. */
function hit(items, x, y) {
    for (let i = items.length - 1; i >= 0; i--) {
        const it = items[i];
        if ((!it.box || inside(it.box, x, y)) && inside(it, x, y)) return i;
    }
    return -1;
}

module.exports = { frame, hit, fit, wrap, fmtTime, fmtAgo, updated, parseInput, statusOf, historyRows, feedOf, W, H, CARD_STEP, CARD_Y, MAX_ROWS, CARDS_SHOWN, FULL, pictureBox };
